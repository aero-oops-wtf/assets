/**
 * Aero Helper — background service worker.
 *
 * Executes `aero.fetch` requests on behalf of Aero skill actions, using the
 * user's own browser session (cookies / SSO) to reach intranet hosts that
 * Aero's air-gapped server cannot.
 *
 * Policy enforced here mirrors the server-side proxy (src/api/skills.rs):
 *   - http(s) URLs only, method whitelist
 *   - the skill's allowed-hosts list (wildcards + optional port)
 *   - hard block of localhost / private / link-local / metadata hosts
 *   - 30s timeout, 2 MB response cap, utf8-or-base64 body encoding
 *   - after redirects, the FINAL url must still pass the host policy
 *
 * The request arrives fully substituted ({{env.NAME}} already resolved by
 * the page from the user's local store) — this worker neither stores nor
 * logs secrets.
 */

'use strict';

const TIMEOUT_MS = 30_000;
const MAX_RESP_BYTES = 2 * 1024 * 1024;
const ALLOWED_METHODS = ['GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE'];

// No hardcoded origin list — the content script self-gates on Aero's
// `<meta name="aero-oops-wtf">` marker, and sender.id === chrome.runtime.id
// guarantees only our own content script can reach this worker. The
// per-request host policy (allowedHosts) is the real security boundary.

// Headers the page must not smuggle in (the browser blocks most of these
// anyway; filtering keeps behavior predictable instead of throwing).
const FORBIDDEN_HEADERS = new Set([
  'host', 'connection', 'content-length', 'transfer-encoding', 'upgrade',
  'cookie', 'cookie2', 'origin', 'referer', 'te', 'trailer', 'keep-alive',
  'proxy-authorization', 'sec-fetch-dest', 'sec-fetch-mode', 'sec-fetch-site',
]);

/** Mirror of src/api/skills.rs host_blocked(). */
function hostBlocked(host) {
  if (
    host === 'localhost' ||
    host.endsWith('.localhost') ||
    host === 'metadata.google.internal' ||
    host.endsWith('.internal')
  ) {
    return true;
  }
  const bare = host.replace(/^\[|\]$/g, '');
  // IPv4 literal
  const m = bare.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
  if (m) {
    const [a, b] = [Number(m[1]), Number(m[2])];
    if (a === 127 || a === 10 || a === 0) return true; // loopback, private, unspecified
    if (a === 172 && b >= 16 && b <= 31) return true; // private
    if (a === 192 && b === 168) return true; // private
    if (a === 169 && b === 254) return true; // link-local
    if (bare === '255.255.255.255') return true; // broadcast
    return false;
  }
  // IPv6 literal
  if (bare.includes(':')) {
    const v6 = bare.toLowerCase();
    if (v6 === '::1' || v6 === '::' || v6 === '0:0:0:0:0:0:0:1' || v6 === '0:0:0:0:0:0:0:0') return true;
  }
  return false;
}

/** Mirror of src/api/skills.rs host_allowed(). */
function hostAllowed(host, port, allowed) {
  for (const entry of allowed) {
    let entryHost = entry;
    let entryPort = null;
    const idx = entry.lastIndexOf(':');
    if (idx > 0 && /^\d+$/.test(entry.slice(idx + 1))) {
      entryHost = entry.slice(0, idx);
      entryPort = Number(entry.slice(idx + 1));
    }
    if (entryPort !== null && entryPort !== port) continue;
    if (entryHost.startsWith('*.')) {
      const suffix = entryHost.slice(2);
      if (host === suffix || host.endsWith('.' + suffix)) return true;
    } else if (host === entryHost) {
      return true;
    }
  }
  return false;
}

/** Returns null when ok, or an error string. */
function checkUrl(urlStr, allowedHosts) {
  let url;
  try {
    url = new URL(urlStr);
  } catch {
    return 'invalid_url: ' + urlStr;
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') {
    return 'invalid_url: http(s) only';
  }
  const host = url.hostname.toLowerCase();
  const port = url.port ? Number(url.port) : url.protocol === 'http:' ? 80 : 443;
  if (hostBlocked(host)) {
    return 'host_blocked: ' + host;
  }
  if (!hostAllowed(host, port, allowedHosts)) {
    return (
      'host_not_allowed: ' + host +
      ' (allowed: ' + (allowedHosts.join(', ') || 'none') +
      ' — the skill owner must add this host to the skill\u2019s allowed hosts)'
    );
  }
  return null;
}

async function doFetch(req) {
  const allowedHosts = Array.isArray(req.allowedHosts) ? req.allowedHosts.map(String) : [];
  const urlErr = checkUrl(String(req.url || ''), allowedHosts);
  if (urlErr) throw new Error(urlErr);

  const method = String(req.method || 'GET').toUpperCase();
  if (!ALLOWED_METHODS.includes(method)) throw new Error('invalid_method: ' + method);

  const headers = {};
  for (const [k, v] of Object.entries(req.headers || {})) {
    if (FORBIDDEN_HEADERS.has(k.toLowerCase())) continue;
    headers[k] = String(v);
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  let resp;
  try {
    resp = await fetch(req.url, {
      method,
      headers,
      body: method === 'GET' || method === 'HEAD' ? undefined : req.body ?? undefined,
      credentials: 'include', // the point: ride the user's intranet session
      redirect: 'follow',
      signal: controller.signal,
    });

    // Redirects may hop hosts; the landing host must also pass policy.
    if (resp.url && resp.url !== req.url) {
      const redirErr = checkUrl(resp.url, allowedHosts);
      if (redirErr) throw new Error('redirected to disallowed url — ' + redirErr);
    }

    const respHeaders = {};
    resp.headers.forEach((v, k) => {
      respHeaders[k] = v;
    });

    const buf = new Uint8Array(await resp.arrayBuffer());
    const truncated = buf.length > MAX_RESP_BYTES;
    const capped = truncated ? buf.slice(0, MAX_RESP_BYTES) : buf;

    // utf8 when the bytes decode cleanly, base64 otherwise — same contract
    // as the server proxy.
    let body, encoding;
    try {
      body = new TextDecoder('utf-8', { fatal: true }).decode(capped);
      encoding = 'utf8';
    } catch {
      let bin = '';
      const CHUNK = 0x8000;
      for (let i = 0; i < capped.length; i += CHUNK) {
        bin += String.fromCharCode.apply(null, capped.subarray(i, i + CHUNK));
      }
      body = btoa(bin);
      encoding = 'base64';
    }

    return { status: resp.status, headers: respHeaders, body, encoding, truncated };
  } catch (e) {
    if (e && e.name === 'AbortError') {
      throw new Error('upstream timeout after ' + TIMEOUT_MS / 1000 + 's');
    }
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'aero-fetch') return false;

  // Only our own content scripts — nobody else can message our worker.
  if (sender.id !== chrome.runtime.id) {
    sendResponse({ ok: false, error: 'forbidden sender' });
    return false;
  }

  doFetch(msg.req || {}).then(
    (response) => sendResponse({ ok: true, response }),
    (err) => sendResponse({ ok: false, error: err && err.message ? err.message : String(err) }),
  );
  return true; // async sendResponse
});
