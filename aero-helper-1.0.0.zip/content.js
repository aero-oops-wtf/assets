/**
 * Aero Helper — content script.
 *
 * Injected on all pages (see content_scripts.matches in manifest.json) but
 * stays DORMANT until it detects Aero's meta marker in the DOM:
 *   <meta name="aero-oops-wtf" content="true">
 * (see frontend/index.html). Non-Aero pages never see the hello, can't
 * trigger fetches, and the script costs nothing but a meta-tag check.
 *
 * Bridges the page to the background service worker:
 *   page ── window.postMessage ──▶ content ── runtime.sendMessage ──▶ background
 *   page ◀─ window.postMessage ── content ◀───────── response ────── background
 *
 * Protocol (all messages carry a `source` tag so unrelated postMessage
 * traffic is ignored):
 *   page → helper : { source: 'aero-oops-wtf-page',   type: 'ping' }
 *   page → helper : { source: 'aero-oops-wtf-page',   type: 'fetch', id, req }
 *   helper → page : { source: 'aero-oops-wtf-helper', type: 'hello', version }
 *   helper → page : { source: 'aero-oops-wtf-helper', type: 'fetch-result', id, ok, response?, error? }
 */

'use strict';

var VERSION = chrome.runtime.getManifest().version;
var activated = false;

function announce() {
  window.postMessage(
    { source: 'aero-oops-wtf-helper', type: 'hello', version: VERSION },
    window.location.origin
  );
}

/** Detect Aero's meta marker and activate once. */
function tryActivate() {
  if (activated) return;
  var meta = document.querySelector('meta[name="aero-oops-wtf"][content="true"]');
  if (!meta) return;
  activated = true;
  announce();
}

// document_start runs before <head> exists; poll for the meta tag.
// A MutationObserver catches it whether it's in the static HTML or injected
// later by the SPA router.
var observer = new MutationObserver(tryActivate);
observer.observe(document.documentElement, { childList: true, subtree: true });
tryActivate();

window.addEventListener('message', function (ev) {
  if (!activated) return;
  if (ev.source !== window || ev.origin !== window.location.origin) return;
  var d = ev.data;
  if (!d || d.source !== 'aero-oops-wtf-page') return;

  if (d.type === 'ping') {
    announce();
    return;
  }

  if (d.type === 'fetch' && typeof d.id === 'string') {
    var id = d.id;
    chrome.runtime.sendMessage({ type: 'aero-fetch', req: d.req }, function (resp) {
      if (chrome.runtime.lastError) {
        window.postMessage(
          {
            source: 'aero-oops-wtf-helper',
            type: 'fetch-result',
            id: id,
            ok: false,
            error: 'helper extension unavailable: ' + chrome.runtime.lastError.message +
              ' (try reloading the extension on chrome://extensions)',
          },
          window.location.origin
        );
        return;
      }
      window.postMessage(
        {
          source: 'aero-oops-wtf-helper',
          type: 'fetch-result',
          id: id,
          ok: !!(resp && resp.ok),
          response: resp && resp.response,
          error: resp && resp.error,
        },
        window.location.origin
      );
    });
  }
});
