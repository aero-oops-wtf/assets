/**
 * Aero Helper — content script.
 *
 * Injected on all pages (see content_scripts.matches in manifest.json) but
 * stays DORMANT until it detects Aero's meta marker in the DOM:
 *   <meta name="aero-oops-wtf" content="true">
 * (see frontend/index.html). Non-Aero pages never see the hello, can't
 * trigger fetches, and the script costs nothing but a meta-tag check.
 *
 * Bridges the page to the background service worker:
 *   page ── window.postMessage ──▶ content ── runtime.sendMessage ──▶ background
 *   page ◀─ window.postMessage ── content ◀───────── response ────── background
 *
 * Protocol (all messages carry a `source` tag so unrelated postMessage
 * traffic is ignored):
 *   page → helper : { source: 'aero-oops-wtf-page',   type: 'ping' }
 *   page → helper : { source: 'aero-oops-wtf-page',   type: 'fetch',  id, req }
 *   page → helper : { source: 'aero-oops-wtf-page',   type: 'browse', id, req }
 *   helper → page : { source: 'aero-oops-wtf-helper', type: 'hello', version }
 *   helper → page : { source: 'aero-oops-wtf-helper', type: 'fetch-result',  id, ok, response?, error? }
 *   helper → page : { source: 'aero-oops-wtf-helper', type: 'browse-result', id, ok, result?,   error? }
 *
 * `fetch` performs a request; `browse` drives a tab the extension itself
 * opened (see background.js's browse section). Both are one round trip with
 * a page-supplied `id`, and neither can be cancelled once sent.
 */

'use strict';

var VERSION = chrome.runtime.getManifest().version;
var activated = false;

function announce() {
  window.postMessage(
    { source: 'aero-oops-wtf-helper', type: 'hello', version: VERSION },
    window.location.origin
  );
}

/** Detect Aero's meta marker and activate once. */
function tryActivate() {
  if (activated) return;
  var meta = document.querySelector('meta[name="aero-oops-wtf"][content="true"]');
  if (!meta) return;
  activated = true;
  announce();
}

// document_start runs before <head> exists; poll for the meta tag.
// A MutationObserver catches it whether it's in the static HTML or injected
// later by the SPA router.
var observer = new MutationObserver(tryActivate);
observer.observe(document.documentElement, { childList: true, subtree: true });
tryActivate();

/**
 * The request types this relay carries. The two differ only in which worker
 * message they name and what the reply field is called, so they share one
 * path through the listener below.
 *
 * Module scope: it never varies per call, and the listener runs on every
 * ping, fetch and browse.
 *
 * Null-prototype, and read through hasOwnProperty: a plain object literal
 * would answer `type === 'toString'` with an inherited function, which is
 * truthy and would then be read for `.message`/`.reply`. Only an activated
 * same-origin page can reach the listener, so this is a shape guard rather
 * than a live hole — but the page half of this bridge is the untrusted half.
 */
var KINDS = Object.create(null);
KINDS.fetch = { message: 'aero-fetch', reply: 'fetch-result', payload: 'response' };
KINDS.browse = { message: 'aero-browse', reply: 'browse-result', payload: 'result' };

function kindOf(type) {
  if (typeof type !== 'string') return null;
  if (!Object.prototype.hasOwnProperty.call(KINDS, type)) return null;
  return KINDS[type];
}

window.addEventListener('message', function (ev) {
  if (!activated) return;
  if (ev.source !== window || ev.origin !== window.location.origin) return;
  var d = ev.data;
  if (!d || d.source !== 'aero-oops-wtf-page') return;

  if (d.type === 'ping') {
    announce();
    return;
  }

  var kind = kindOf(d.type);
  if (kind && typeof d.id === 'string') {
    var id = d.id;
    chrome.runtime.sendMessage({ type: kind.message, req: d.req }, function (resp) {
      if (chrome.runtime.lastError) {
        window.postMessage(
          {
            source: 'aero-oops-wtf-helper',
            type: kind.reply,
            id: id,
            ok: false,
            error: 'helper extension unavailable: ' + chrome.runtime.lastError.message +
              ' (try reloading the extension on chrome://extensions)',
          },
          window.location.origin
        );
        return;
      }
      var out = {
        source: 'aero-oops-wtf-helper',
        type: kind.reply,
        id: id,
        ok: !!(resp && resp.ok),
        error: resp && resp.error,
      };
      out[kind.payload] = resp && resp[kind.payload];
      window.postMessage(out, window.location.origin);
    });
  }
});
