/**
 * Aero Helper — background service worker.
 *
 * Executes `aero.fetch` requests on behalf of Aero skill actions, using the
 * user's own browser session (cookies / SSO) to reach intranet hosts that
 * Aero's air-gapped server cannot.
 *
 * This worker IS the policy. The deployment is air-gapped — there is no
 * server-side proxy to mirror; src/api/skills.rs stores a skill's
 * `allowed_hosts` list and never fetches anything itself. So what is
 * enforced here is enforced nowhere else:
 *   - http(s) URLs only, method whitelist
 *   - the skill's allowed-hosts list (wildcards + optional port)
 *   - hard block of localhost / private / link-local / metadata hosts
 *   - 30s timeout, 2 MB response cap, utf8-or-base64 body encoding
 *   - after redirects, the FINAL url must still pass the host policy
 *
 * Browsing (see the browse section below) is the one path with NO allowed-
 * hosts list, because there is no skill behind it to declare one. It is
 * bounded by tab ownership instead; its own header explains the trade.
 *
 * The request arrives fully substituted ({{env.NAME}} already resolved by
 * the page from the user's local store) — this worker neither stores nor
 * logs secrets.
 */

'use strict';

const TIMEOUT_MS = 30_000;
const MAX_RESP_BYTES = 2 * 1024 * 1024;
const ALLOWED_METHODS = ['GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE'];

// No hardcoded origin list — the content script self-gates on Aero's
// `<meta name="aero-oops-wtf">` marker, and sender.id === chrome.runtime.id
// guarantees only our own content script can reach this worker. The
// per-request host policy (allowedHosts) is the real security boundary.

// Headers the page must not smuggle in (the browser blocks most of these
// anyway; filtering keeps behavior predictable instead of throwing).
const FORBIDDEN_HEADERS = new Set([
  'host', 'connection', 'content-length', 'transfer-encoding', 'upgrade',
  'cookie', 'cookie2', 'origin', 'referer', 'te', 'trailer', 'keep-alive',
  'proxy-authorization', 'sec-fetch-dest', 'sec-fetch-mode', 'sec-fetch-site',
]);

/**
 * Addresses a skill's own request may never reach.
 *
 * This gates the fetch path only, and it is a real boundary there: those URLs
 * come from a skill, which someone else may have written and shared, so
 * without this an installed skill could make the user's browser hit their own
 * machine. Browsing does NOT use it — see the browse section's header for why
 * an address filter is wrong for that path.
 *
 * Note what is deliberately NOT here: the `.internal` TLD as a whole. ICANN
 * reserved it for exactly the private use an org puts its intranet on, so
 * blocking the suffix would refuse legitimate hosts and the failure would
 * read as a bug rather than a policy. `metadata.google.internal` is named
 * individually because it is a credential endpoint, not merely internal.
 */
function hostBlocked(host) {
  if (
    host === 'localhost' ||
    host.endsWith('.localhost') ||
    host === 'metadata.google.internal'
  ) {
    return true;
  }
  const bare = host.replace(/^\[|\]$/g, '');
  // IPv4 literal
  const m = bare.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
  if (m) {
    const [a, b] = [Number(m[1]), Number(m[2])];
    if (a === 127 || a === 10 || a === 0) return true; // loopback, private, unspecified
    if (a === 172 && b >= 16 && b <= 31) return true; // private
    if (a === 192 && b === 168) return true; // private
    if (a === 169 && b === 254) return true; // link-local
    if (bare === '255.255.255.255') return true; // broadcast
    return false;
  }
  // IPv6 literal
  if (bare.includes(':')) {
    const v6 = bare.toLowerCase();
    if (v6 === '::1' || v6 === '::' || v6 === '0:0:0:0:0:0:0:1' || v6 === '0:0:0:0:0:0:0:0') return true;
  }
  return false;
}

/** The skill's declared allowed-hosts list — wildcards and optional port. */
function hostAllowed(host, port, allowed) {
  for (const entry of allowed) {
    let entryHost = entry;
    let entryPort = null;
    const idx = entry.lastIndexOf(':');
    if (idx > 0 && /^\d+$/.test(entry.slice(idx + 1))) {
      entryHost = entry.slice(0, idx);
      entryPort = Number(entry.slice(idx + 1));
    }
    if (entryPort !== null && entryPort !== port) continue;
    if (entryHost.startsWith('*.')) {
      const suffix = entryHost.slice(2);
      if (host === suffix || host.endsWith('.' + suffix)) return true;
    } else if (host === entryHost) {
      return true;
    }
  }
  return false;
}

/** Returns null when ok, or an error string. */
function checkUrl(urlStr, allowedHosts) {
  let url;
  try {
    url = new URL(urlStr);
  } catch {
    return 'invalid_url: ' + urlStr;
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') {
    return 'invalid_url: http(s) only';
  }
  const host = url.hostname.toLowerCase();
  const port = url.port ? Number(url.port) : url.protocol === 'http:' ? 80 : 443;
  if (hostBlocked(host)) {
    return 'host_blocked: ' + host;
  }
  if (!hostAllowed(host, port, allowedHosts)) {
    return (
      'host_not_allowed: ' + host +
      ' (allowed: ' + (allowedHosts.join(', ') || 'none') +
      ' — the skill owner must add this host to the skill\u2019s allowed hosts)'
    );
  }
  return null;
}

async function doFetch(req) {
  const allowedHosts = Array.isArray(req.allowedHosts) ? req.allowedHosts.map(String) : [];
  const urlErr = checkUrl(String(req.url || ''), allowedHosts);
  if (urlErr) throw new Error(urlErr);

  const method = String(req.method || 'GET').toUpperCase();
  if (!ALLOWED_METHODS.includes(method)) throw new Error('invalid_method: ' + method);

  const headers = {};
  for (const [k, v] of Object.entries(req.headers || {})) {
    if (FORBIDDEN_HEADERS.has(k.toLowerCase())) continue;
    headers[k] = String(v);
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  let resp;
  try {
    resp = await fetch(req.url, {
      method,
      headers,
      body: method === 'GET' || method === 'HEAD' ? undefined : req.body ?? undefined,
      credentials: 'include', // the point: ride the user's intranet session
      redirect: 'follow',
      signal: controller.signal,
    });

    // Redirects may hop hosts; the landing host must also pass policy.
    if (resp.url && resp.url !== req.url) {
      const redirErr = checkUrl(resp.url, allowedHosts);
      if (redirErr) throw new Error('redirected to disallowed url — ' + redirErr);
    }

    const respHeaders = {};
    resp.headers.forEach((v, k) => {
      respHeaders[k] = v;
    });

    const buf = new Uint8Array(await resp.arrayBuffer());
    const truncated = buf.length > MAX_RESP_BYTES;
    const capped = truncated ? buf.slice(0, MAX_RESP_BYTES) : buf;

    // utf8 when the bytes decode cleanly, base64 otherwise. The flag rides
    // through to the action as `encoding` (see the aero.fetch contract in
    // frontend/src/skills/learn-skills.md); nothing decodes it on the way.
    let body, encoding;
    try {
      body = new TextDecoder('utf-8', { fatal: true }).decode(capped);
      encoding = 'utf8';
    } catch {
      let bin = '';
      const CHUNK = 0x8000;
      for (let i = 0; i < capped.length; i += CHUNK) {
        bin += String.fromCharCode.apply(null, capped.subarray(i, i + CHUNK));
      }
      body = btoa(bin);
      encoding = 'base64';
    }

    return { status: resp.status, headers: respHeaders, body, encoding, truncated };
  } catch (e) {
    if (e && e.name === 'AbortError') {
      throw new Error('upstream timeout after ' + TIMEOUT_MS / 1000 + 's');
    }
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

// ---------------------------------------------------------------------------
// Browse: drive a real tab.
//
// This is a general read-and-act primitive over a live page — the broadest
// thing this worker does by some distance, since everything above it acts on
// a URL a skill named and returns only that request's own response. It exists
// because authoring a skill for an intranet app means looking at that app,
// and the alternative is the user reverse-engineering it by hand. What makes
// it defensible is a different shape of limit — not an allowed-hosts list
// (there is none here; the user asked for any host), but:
//
//   - OWNERSHIP. Browse only ever touches tabs it opened itself. It will not
//     attach to the user's existing tabs. A general read primitive pointed at
//     a tab the user already had open is a way to read whatever happens to be
//     in it — a signed-in mailbox, an internal record — and no allowed-hosts
//     list would help, because the tab is already there.
//   - The CALLING PAGE's own origin is refused, so an agent cannot drive the
//     UI that is driving it. Note the check is against the caller's origin,
//     not a fixed aero domain — with instances at arbitrary origins that is
//     the only form of it that means anything, and it is why one instance
//     is not protected from another.
//   - The feature is off until the user switches it on (a default-off tool
//     toggle in the frontend), and the tab is visibly pinned while it runs.
//
// WHO MAY CALL THIS, precisely — the bullets above are all that bound it, so
// be clear about the premise they rest on. content.js activates on any
// top-level document carrying `<meta name="aero-oops-wtf" content="true">`,
// which is a string any site can serve; there is no origin allowlist, and
// there cannot be a useful one, since aero runs at whatever origin serves
// the binary (see PUBLIC_BASE_URL in src/mcp.rs) and an instance's identity
// is unprovable — every check an origin could pass, an impostor can serve.
// So "the user's own agent session" is the intended caller, not an enforced
// one: in practice ANY top-level page the user visits can drive a browse
// tab, including at origins that have nothing to do with aero. That is
// accepted deliberately, to keep third-party and self-hosted instances
// first-class without a registry or a blessing step.
//
// What would change the calculus: making the caller set the user's decision
// rather than the page's — a trusted-origin list the user adds to from the
// extension's own UI, checked against `ownerOrigin` in the aero-browse
// listener below. Iframes are already excluded (content.js sets no
// `all_frames`), so this is top-level documents only.
//
// Deliberately NOT bounded by address shape either. `hostBlocked` still
// gates the fetch path, where the URL comes from a skill someone else may
// have written and shared — there it is a real SSRF boundary. Here an
// address filter would break the purpose: loopback and private ranges are
// exactly where a service under development and the intranet apps this
// exists to look at live.
//
// Skills cannot use this path, so nothing published gains reach from it.
// The residual is prompt injection: page text naming a local URL for the
// agent to read back. What bounds that is the toggle, the untrusted-content
// marking on every result, and the personas being told to browse only a URL
// the user gave them — not an address list.
//
// Page CONTENT that comes back is attacker-controlled input: the frontend
// marks it untrusted before the model sees it. Nothing here can enforce that.
// ---------------------------------------------------------------------------

/** How long to wait for a navigation to settle. */
const BROWSE_LOAD_WAIT_MS = 20_000;
/**
 * How long one in-page op may run before the worker gives up on it. Under
 * the frontend's 45s so the client sees this message rather than its own.
 *
 * This bounds the CALLER, not the script: chrome cannot cancel an
 * executeScript already sent. What bounds the tab lock is the pair of this
 * and BROWSE_DRAIN_GRACE_MS below — a page that pre-defines `window.__aeroDom`
 * with an `act()` that never settles would otherwise hold the lock forever,
 * and every later op on that tab (the escape hatches included) would queue
 * behind it.
 */
const BROWSE_OP_TIMEOUT_MS = 40_000;
/**
 * How long the next op waits for work the previous one abandoned.
 *
 * Short on purpose. The abandoned op has already had its full timeout, so
 * this is only the settling window for a script that was about to finish
 * anyway; anything still running past it is treated as stuck rather than
 * slow. See `drainInFlight` for what happens then.
 */
const BROWSE_DRAIN_GRACE_MS = 10_000;
/**
 * How long `settleTab` keeps distrusting a 'complete' it has not seen the
 * tab load its way into (see there). Only a same-URL load that finished
 * between two polls ever waits this long.
 */
const BROWSE_SETTLE_GRACE_MS = 1_000;
/**
 * Cap on the engine's page-state text. The engine's own BUDGET is 5000
 * chars, so on the honest path this never binds; it exists for a page that
 * pre-defined `window.__aeroDom` to answer in the engine's place, and is
 * sized just above the budget so that case cannot buy itself more room.
 */
const MAX_BROWSE_TEXT = 8 * 1024;

/**
 * Tabs this worker opened for browsing.
 *
 * Which page opened each is deliberately NOT recorded: any caller may drive
 * any browse tab. The boundary this set draws is worker-vs-user ("did WE
 * open it"), not caller-vs-caller. See the caller-trust note in the browse
 * header for why there is no second boundary to add here.
 *
 * Lost when the service worker restarts — MV3 workers are ephemeral, and
 * this is not persisted because recovery is cheap: the next op on a
 * forgotten tab is refused with a message telling the model to navigate
 * again, which gets it a fresh one. The orphaned pinned tab is left for the
 * user to close rather than being adopted back, since a tab this worker
 * cannot prove it opened is exactly what the set exists to exclude.
 */
const browseTabs = new Set();

/**
 * Serialize ops per tab. A client-side timeout followed by a retry would
 * otherwise interleave two ops in one document — the second reading a page
 * the first is still clicking through.
 */
const browseLocks = new Map();

/**
 * Work dispatched into a tab that has outlived the caller waiting for it.
 *
 * `runEngineOp` races a deadline, but losing that race abandons the CALLER,
 * not the script: chrome cannot cancel an executeScript already sent, the
 * same way JS already executing in a page cannot be aborted from here. So a
 * timed-out op is still clicking through the document. Releasing the lock
 * when the deadline fires would let the retry — which is exactly what a model
 * reaches for after a timeout — run against a page the previous op is still
 * driving, i.e. the one race this lock exists to prevent. The next op
 * therefore waits for this too.
 */
const browseInFlight = new Map();

chrome.tabs.onRemoved.addListener((tabId) => {
  browseTabs.delete(tabId);
  // `browseInFlight` self-clears once its work settles, but a lock chain
  // never does: it is only ever replaced, so a closed tab's last one would
  // sit in the map for the life of the worker. Small, but unbounded across a
  // long session that opens many tabs. Dropping it is safe — anything still
  // queued on it holds its own reference and runs to completion; a later op
  // on a recycled id just starts a fresh chain, which is correct, since the
  // tab it would have been serialising against is gone.
  browseLocks.delete(tabId);
});

/** Note work still running in `tabId`, so the next lock holder waits for it. */
function trackInFlight(tabId, work) {
  const prev = browseInFlight.get(tabId);
  const own = work.then(
    () => {},
    () => {},
  );
  // Combined with anything already pending rather than replacing it. Nothing
  // should double-inject into one tab — the timeout path is rethrown before
  // it can — but a plain `set` would silently drop a still-running op from
  // the drain's view if some future path did, which is the failure this map
  // exists to prevent.
  const quiet = prev ? Promise.all([prev, own]).then(() => {}) : own;
  browseInFlight.set(tabId, quiet);
  void quiet.then(() => {
    // Only clear our own entry: a later op may already have replaced it.
    if (browseInFlight.get(tabId) === quiet) browseInFlight.delete(tabId);
  });
  return quiet;
}

/**
 * Wait for work abandoned in `tabId` — but not forever.
 *
 * A page whose JS thread is wedged never lets its executeScript settle, and
 * a lock that waited on it unconditionally would queue every later op behind
 * a promise that never resolves: a hang traded for a race. Past the grace
 * period the tab is treated as unrecoverable and closed. That resolves the
 * race the honest way rather than by ignoring it — with no tab there is
 * nothing left to interleave with, and the model is told to navigate again,
 * which gets it a clean one.
 */
async function drainInFlight(tabId) {
  const pending = browseInFlight.get(tabId);
  if (!pending) return;
  let timer;
  const stuck = new Promise((resolve) => {
    timer = setTimeout(() => resolve(true), BROWSE_DRAIN_GRACE_MS);
  });
  const isStuck = await Promise.race([pending.then(() => false), stuck]);
  clearTimeout(timer);
  if (!isStuck) return;
  browseInFlight.delete(tabId);
  browseTabs.delete(tabId);
  await chrome.tabs.remove(tabId).catch(() => {});
}

function withBrowseLock(tabId, fn) {
  const prev = browseLocks.get(tabId) || Promise.resolve();
  const next = prev.then(fn, fn);
  // The chained promise is what the NEXT op waits for, and it deliberately
  // outlasts what this caller awaits — see browseInFlight. With nothing
  // abandoned the map is empty and the drain returns immediately.
  browseLocks.set(
    tabId,
    next.then(
      () => drainInFlight(tabId),
      () => drainInFlight(tabId),
    ),
  );
  return next;
}

/**
 * The URL policy for browsing: real http(s), and not Aero itself.
 * Deliberately NOT `hostAllowed` or `hostBlocked` — browsing has no skill
 * behind it to declare hosts, and the user opted into "any host".
 */
function checkBrowseUrl(urlStr, ownerOrigin) {
  let url;
  try {
    url = new URL(urlStr);
  } catch {
    return 'invalid_url: ' + urlStr;
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') {
    return 'invalid_url: http(s) only';
  }
  // An unknown owner fails closed, never open: it is the one input the
  // self-origin refusal below depends on, so skipping the check when it is
  // missing would let an unidentifiable sender into Aero's own origin. The
  // caller refuses earlier too; this copy survives a future one that
  // forgets.
  if (!ownerOrigin) {
    return 'refused: could not determine which page asked, so the self-origin check cannot run';
  }
  // Aero's own origin is refused so the agent cannot drive the UI that is
  // driving it — except under /p/, which is a published page: user content,
  // not the management UI. "Look at my published page and check it renders"
  // is a real request the preview tools cannot answer, because the preview is
  // sandboxed and shim-injected and the published page is neither.
  //
  // Path-based and therefore only as good as the path staying put, which is
  // why it is safe here: a published page IS same-origin with /api/*, so a
  // click that walks into the app would be a way back to the UI — and
  // settleTab re-runs this check on where the tab actually landed, so that
  // click closes the tab instead.
  if (url.origin === ownerOrigin && !isPublishedPagePath(url.pathname)) {
    return 'refused: that is Aero\u2019s own UI. Browsing may open Aero\u2019s published pages under /p/, but use the page and skill tools for anything else here.';
  }
  return null;
}

/**
 * `/p/<slug>` — a published page.
 *
 * Exactly `src/public.rs::matches`, which is `starts_with("/p/")` and nothing
 * else. The prefix must match it character for character: anything this
 * accepts that the server does not route to `public::serve` falls through to
 * `spa::serve` instead, which is the authenticated management UI — the one
 * thing the self-origin refusal above exists to keep the agent out of. A bare
 * `/p` is precisely that case and is NOT a published page.
 *
 * Deeper paths like `/p/a/b` do match here, and safely: the server answers
 * them from `public::serve` with a 404, never from the SPA.
 */
function isPublishedPagePath(pathname) {
  return pathname.startsWith('/p/');
}

/**
 * Wait for a tab to finish loading, then re-check where it actually landed.
 *
 * `from` is the URL the tab showed before the action that may have moved it,
 * and `navigating` says a move is known to be under way. Both exist for one
 * race: `chrome.tabs.update` resolves once a navigation is *initiated*, and
 * the tab's status does not flip to 'loading' synchronously — so the first
 * poll can catch the OLD document still reporting 'complete' and this would
 * hand back a map of the page about to be replaced. When `navigating` is
 * set, 'complete' only counts once the tab has been seen loading or its URL
 * has left `from`; BROWSE_SETTLE_GRACE_MS covers a same-URL load that was
 * quick enough to finish between polls.
 */
async function settleTab(tabId, ownerOrigin, opts) {
  const from = (opts && opts.from) || '';
  const navigating = Boolean(opts && opts.navigating);
  const start = Date.now();
  const deadline = start + BROWSE_LOAD_WAIT_MS;
  let sawLoading = false;
  for (;;) {
    let tab;
    try {
      tab = await chrome.tabs.get(tabId);
    } catch {
      browseTabs.delete(tabId);
      throw new Error('the browse tab was closed');
    }
    if (tab.status !== 'complete') sawLoading = true;
    const trusted =
      !navigating || sawLoading || (tab.url || '') !== from || Date.now() - start >= BROWSE_SETTLE_GRACE_MS;
    // Past the deadline, act on what has rendered rather than failing. A
    // page still loading has already committed to its URL, so the policy
    // check below still applies — skipping it would make "load slowly" a
    // way past it.
    if ((tab.status === 'complete' && trusted) || Date.now() >= deadline) {
      // A redirect can land somewhere the opening URL was not: re-run the
      // policy on where we ENDED UP, the same way the fetch path re-checks
      // resp.url after following redirects.
      const err = checkBrowseUrl(tab.url || '', ownerOrigin);
      if (err) {
        browseTabs.delete(tabId);
        await chrome.tabs.remove(tabId).catch(() => {});
        throw new Error('navigation ended somewhere it may not go — ' + err);
      }
      return tab;
    }
    await new Promise((r) => setTimeout(r, 300));
  }
}

/** Install the DOM engine (idempotent) and run one op in the page. */
function runEngineOp(tabId, op, args, generation) {
  const inner = runEngineOpInner(tabId, op, args, generation);
  // Registered BEFORE the race, so that losing the race hands the lock
  // something to wait on rather than nothing.
  trackInFlight(tabId, inner);
  let timer;
  const deadline = new Promise((_, reject) => {
    timer = setTimeout(() => {
      const err = new Error(
        'the page did not finish the action within ' + BROWSE_OP_TIMEOUT_MS / 1000 + 's',
      );
      // Tagged because the caller must tell OUR deadline from the realm
      // going away, and the two are indistinguishable from tab state alone.
      // A deadline means the injected code is still running; a realm that
      // went away means it is not. See doBrowse's catch.
      err.aeroOpTimedOut = true;
      reject(err);
    }, BROWSE_OP_TIMEOUT_MS);
  });
  return Promise.race([inner, deadline]).finally(() => clearTimeout(timer));
}

async function runEngineOpInner(tabId, op, args, generation) {
  await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    files: ['dom-engine.js'],
  });
  const [res] = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func: (op_, args_, gen_) =>
      window.__aeroDom
        .act(op_, args_, gen_, 'allow')
        .then((r) => ({ ok: true, result: r, generation: window.__aeroDom.currentGeneration() }))
        .catch((e) => ({
          ok: false,
          error: (e && e.message) || String(e),
          generation: window.__aeroDom.currentGeneration(),
        })),
    args: [op, args || {}, typeof generation === 'number' ? generation : null],
  });
  return res && res.result;
}

/** Nothing the page returned is trusted: rebuild it, with every field capped. */
function sanitizeBrowseResult(raw) {
  const out = {};
  if (!raw || typeof raw !== 'object') return out;
  const st = raw && raw.page_state;
  if (st && typeof st === 'object') {
    let text = typeof st.elements === 'string' ? st.elements : '';
    let clipped = false;
    if (text.length > MAX_BROWSE_TEXT) {
      text = text.slice(0, MAX_BROWSE_TEXT);
      clipped = true;
    }
    out.page_state = {
      title: String(st.title || '').slice(0, 300),
      scroll_y: Number(st.scroll_y) || 0,
      page_height: Number(st.page_height) || 0,
      viewport_height: Number(st.viewport_height) || 0,
      interactive_count: Number(st.interactive_count) || 0,
      elements: text,
    };
    if (st.truncated || clipped) out.page_state.truncated = true;
    if (st.note) out.page_state.note = String(st.note).slice(0, 500);
  }
  if (raw && raw.note) out.note = String(raw.note).slice(0, 500);
  if (raw && raw.effects && typeof raw.effects === 'object') {
    // Dialogs only. would_submit/would_navigate are 'record'-mode artifacts
    // and cannot occur here — browsing performs those for real.
    const dialogs = Array.isArray(raw.effects.dialogs) ? raw.effects.dialogs.slice(0, 10) : [];
    if (dialogs.length) {
      out.effects = {
        dialogs: dialogs.map((d) => {
          const row = {
            kind: String((d && d.kind) || '').slice(0, 20),
            message: String((d && d.message) || '').slice(0, 300),
          };
          // For confirm/prompt: what the engine answered. On a real page that
          // is Cancel (false / null) — see dom-engine.js's guards().
          if (d && 'answered' in d) {
            if (typeof d.answered === 'boolean') {
              row.answered = d.answered;
            } else if (d.answered === null) {
              // prompt, cancelled. Distinct from '' — see dom-engine.js.
              row.answered = null;
            } else {
              row.answered = String(d.answered).slice(0, 100);
            }
          }
          return row;
        }),
      };
    }
  }
  return out;
}

/** Wait for a navigate to land, read the page, and shape the result. */
async function navigateResult(tabId, url, ownerOrigin, from) {
  const tab = await settleTab(tabId, ownerOrigin, { from, navigating: true });
  // A rejection here must still carry tab_id back: executeScript refuses
  // outright on a PDF, a chrome-error:// page after a DNS/TLS failure, or a
  // Web Store URL, and the client only learns the tab's id from a result.
  // Thrown, the tab would stay open, pinned, and unclosable from Aero.
  let read;
  try {
    read = await runEngineOp(tabId, 'read_page_state', {}, null);
  } catch (e) {
    read = { ok: false, error: (e && e.message) || String(e) };
  }
  // Same check as the op path in doBrowse. Without it a failed read returns
  // {url} alone, and the model reasons about a blank page as if the
  // navigate had worked.
  if (!read || read.ok === false) {
    return {
      tab_id: tabId,
      url: tab.url || url,
      error: String((read && read.error) || 'the page loaded but could not be read'),
      generation: (read && read.generation) ?? null,
    };
  }
  return {
    tab_id: tabId,
    url: tab.url || url,
    ...sanitizeBrowseResult(read.result),
    generation: read.generation ?? null,
  };
}

async function doBrowse(req, ownerOrigin) {
  const op = String(req.op || '');

  if (op === 'navigate') {
    const url = String(req.url || '');
    const err = checkBrowseUrl(url, ownerOrigin);
    if (err) throw new Error(err);

    const tabId = Number(req.tabId);
    if (browseTabs.has(tabId)) {
      // Reusing a tab contends with any op still running in it — a navigate
      // is exactly what a model reaches for after a browse timeout, and
      // outside the lock chrome.tabs.update would fire while that op's
      // settleTab is still polling, which then describes the page the retry
      // moved to.
      const reused = await withBrowseLock(tabId, async () => {
        // The user may have closed it since; fall through to a fresh one.
        const prev = await chrome.tabs.get(tabId).catch(() => null);
        if (!prev) return null;
        // Where the tab was before, so settleTab can tell the old document
        // from the new one when both report 'complete'.
        const from = prev.url || '';
        const ok = await chrome.tabs.update(tabId, { url }).then(() => true, () => false);
        if (!ok) return null;
        return navigateResult(tabId, url, ownerOrigin, from);
      });
      if (reused) return reused;
      browseTabs.delete(tabId);
    }
    // Pinned and inactive: visible enough that the user can see something
    // is happening, quiet enough not to steal what they are doing.
    const created = await chrome.tabs.create({ url, active: false, pinned: true });
    browseTabs.add(created.id);
    // Under the lock too, even though a brand-new tab has nothing to contend
    // with yet. Acquiring is not the point here; leaving a chain behind is.
    // Its first read can still blow its deadline, and `withBrowseLock` is
    // what arranges for the next op to drain what that left running. Outside
    // it there is no chain for this tab, so the next op finds none, starts
    // immediately, and its own `trackInFlight` overwrites the abandoned
    // entry — the interleaving race, reopened for this one path.
    return withBrowseLock(created.id, () => navigateResult(created.id, url, ownerOrigin, ''));
  }

  const tabId = Number(req.tabId);
  if (!browseTabs.has(tabId)) {
    throw new Error(
      'no browse tab — call browse_navigate first. (If you had one, the helper restarted and forgot it; navigate again.)',
    );
  }
  if (op === 'close') {
    // Deliberately NOT under the lock. Closing is the escape hatch from a
    // wedged tab, and an escape hatch that queues behind the thing it
    // escapes is not one. An op still running sees "the browse tab was
    // closed", which is the truth.
    browseTabs.delete(tabId);
    await chrome.tabs.remove(tabId).catch(() => {});
    return { closed: true };
  }

  return withBrowseLock(tabId, async () => {
    const before = await chrome.tabs.get(tabId).catch(() => null);
    if (!before) {
      browseTabs.delete(tabId);
      throw new Error('the browse tab was closed');
    }
    const from = before.url || '';

    let raw;
    try {
      raw = await runEngineOp(tabId, op, req.args || {}, req.generation);
    } catch (e) {
      // Our own deadline is never a navigation, and must never be followed
      // by a second injection: chrome cannot cancel an executeScript already
      // sent, so the first op is still driving this document and a re-read
      // would race it over the engine's shared selectorMap/generation, and
      // would overwrite its browseInFlight entry so the drain stops waiting
      // for it.
      //
      // Tab state cannot tell the two apart, which is why this is decided
      // from the error and not from the checks below: an SPA route change via
      // pushState moves `location.href` without destroying the realm, and a
      // tab mid-load of a subresource is not 'complete' either.
      if (e && e.aeroOpTimedOut) throw e;
      // Past here the rejection came from executeScript itself, so the realm
      // really is gone — a click that navigated took the injected code with
      // it. That is a success: wait for the new document and describe it.
      raw = null;
      const after = await chrome.tabs.get(tabId).catch(() => null);
      if (!after) {
        browseTabs.delete(tabId);
        throw new Error('the browse tab was closed');
      }
      if ((after.url || '') === from && after.status === 'complete') throw e;
    }

    if (raw && raw.ok === false) {
      return { error: String(raw.error || 'the action failed'), generation: raw.generation ?? null };
    }

    // `raw === null` means the realm was destroyed under the op, so a
    // navigation is certainly under way and 'complete' from the old document
    // must not be believed. When the op returned normally, a navigation it
    // started asynchronously (a submit on a timer) can still slip through
    // as `to === from` — the model then sees the pre-navigation snapshot,
    // and its next read catches up. Waiting out the grace on every click to
    // close that gap would cost more than it saves.
    const settled = await settleTab(tabId, ownerOrigin, { from, navigating: raw === null });
    const to = settled.url || '';
    if (!raw || to !== from) {
      // Re-read: either the op never returned a snapshot, or it returned one
      // of a document that has since been replaced. Element indices from
      // before the navigation are meaningless, and the fresh read's bumped
      // generation is what tells the model so.
      const reread = await runEngineOp(tabId, 'read_page_state', {}, null);
      const out = {
        ...sanitizeBrowseResult(reread && reread.result),
        generation: (reread && reread.generation) ?? null,
      };
      if (to !== from) out.navigated = { from, to };
      return out;
    }
    return { ...sanitizeBrowseResult(raw.result), generation: raw.generation ?? null };
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'aero-fetch') return false;

  // Only our own content scripts — nobody else can message our worker.
  if (sender.id !== chrome.runtime.id) {
    sendResponse({ ok: false, error: 'forbidden sender' });
    return false;
  }

  doFetch(msg.req || {}).then(
    (response) => sendResponse({ ok: true, response }),
    (err) => sendResponse({ ok: false, error: err && err.message ? err.message : String(err) }),
  );
  return true; // async sendResponse
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'aero-browse') return false;

  if (sender.id !== chrome.runtime.id) {
    sendResponse({ ok: false, error: 'forbidden sender' });
    return false;
  }

  // Which Aero page asked. Taken from the sender rather than the request, so
  // the page cannot name someone else's origin to get past the self-check.
  let ownerOrigin = '';
  try {
    ownerOrigin = new URL((sender.tab && sender.tab.url) || sender.origin || '').origin;
  } catch {
    ownerOrigin = '';
  }

  if (!ownerOrigin) {
    // Nothing legitimate lands here: a content-script sender always carries
    // a tab url or an origin. Refusing beats browsing on behalf of a page we
    // cannot identify, since ownerOrigin is what the self-origin refusal
    // compares against.
    sendResponse({ ok: false, error: 'could not determine which page made the request' });
    return false;
  }

  doBrowse(msg.req || {}, ownerOrigin).then(
    (result) => sendResponse({ ok: true, result }),
    (err) => sendResponse({ ok: false, error: err && err.message ? err.message : String(err) }),
  );
  return true; // async sendResponse
});
