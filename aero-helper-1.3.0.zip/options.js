/**
 * Aero Helper — options page: the origins whose pages may ask the worker for
 * anything (background.js, "Who may ask").
 *
 * The list lives in chrome.storage.local under `trustedOrigins`. Until the
 * user saves one, the worker uses its default (the public instance), and this
 * page shows that default; the first change saves the whole list.
 */

'use strict';

// Kept in step with DEFAULT_TRUSTED_ORIGINS in background.js by hand: an
// options page can't read a service worker's constants.
var DEFAULT_TRUSTED_ORIGINS = ['https://aero.oops.wtf'];

var list = document.getElementById('origins');
var form = document.getElementById('add');
var input = document.getElementById('origin');
var error = document.getElementById('error');

async function load() {
  var saved = (await chrome.storage.local.get('trustedOrigins')).trustedOrigins;
  return Array.isArray(saved) ? saved : DEFAULT_TRUSTED_ORIGINS.slice();
}

async function save(origins) {
  await chrome.storage.local.set({ trustedOrigins: origins });
  render(origins);
}

/** An origin from what the user typed, or null when it isn't an http(s) URL. */
function toOrigin(text) {
  var url;
  try {
    url = new URL(text.trim());
  } catch (e) {
    return null;
  }
  if (url.protocol !== 'https:' && url.protocol !== 'http:') return null;
  return url.origin;
}

function render(origins) {
  list.textContent = '';
  if (origins.length === 0) {
    var empty = document.createElement('li');
    empty.className = 'empty';
    empty.textContent = 'No site can use Aero Helper.';
    list.appendChild(empty);
    return;
  }
  origins.forEach(function (origin) {
    var item = document.createElement('li');
    var code = document.createElement('code');
    code.textContent = origin;
    var remove = document.createElement('button');
    remove.className = 'remove';
    remove.type = 'button';
    remove.textContent = 'Remove';
    remove.addEventListener('click', async function () {
      var current = await load();
      await save(current.filter(function (o) { return o !== origin; }));
    });
    item.appendChild(code);
    item.appendChild(remove);
    list.appendChild(item);
  });
}

form.addEventListener('submit', async function (ev) {
  ev.preventDefault();
  error.textContent = '';
  var origin = toOrigin(input.value);
  if (!origin) {
    error.textContent = 'Enter the address the site is served from, like https://aero.example.com.';
    return;
  }
  var current = await load();
  if (current.indexOf(origin) === -1) await save(current.concat([origin]));
  input.value = '';
});

load().then(render);
