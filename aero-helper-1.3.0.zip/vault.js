/**
 * Aero Helper — the vault: secrets an Aero page may use but never read.
 *
 * Why it exists. A page published on Aero is same-origin with the app, so
 * whatever the app keeps in localStorage or IndexedDB a published page can
 * read and take away: an OpenRouter key, a custom model's key (or a URL with
 * one in it), an MCP server's token. Kept here instead, a secret never
 * reaches page JavaScript. A page names an entry and asks for a request to be
 * made with it; this worker adds the secret, sends the request to that
 * entry's own endpoint and nowhere else, and streams the answer back. What
 * that still allows, and was accepted (2026-11-08): a page at a trusted
 * origin, published pages included, can USE an entry while it is open. It
 * cannot read one, keep one, or point one at another host.
 *
 * Entries live in chrome.storage.local `vault`, keyed by id:
 *   { id, origin, kind, label, url, key, headers, meta, updatedAt }
 *   - origin: the trusted origin whose page created it. Only pages at that
 *     origin see or use it, as localStorage was per-origin before.
 *   - url, key, headers: the secret parts. A URL counts: a Gemini endpoint
 *     takes `&key=`, and MCP servers put keys in paths. Never sent to a page.
 *   - meta: what the page keeps with the entry and reads back (a custom
 *     model's name, format and levels, say). Capped, and never secret.
 *   - values, hosts: a `skill-env` entry's instead of a URL and key: the
 *     skill's secret env values by name, and the only hosts they go to, as
 *     the user saw them when typing the values.
 * storage.local is closed to everything but this worker and the extension's
 * own pages, content scripts included, since those run in a web page's
 * process.
 *
 * How secrets get in: only through the extension's own window (secret.html).
 * A page asks for it to be opened and then asks, by polling, whether the user
 * saved. A page cannot prefill a URL or a key, except to move ones it already
 * holds (`import`, for the move out of localStorage), and then the window
 * lists every destination for the user to confirm. Form requests live in
 * storage.session, so a worker stopped while the user types loses nothing.
 *
 * How requests go out: a port named `vault-fetch` from content.js, one
 * request per port, the answer streamed back as text. `credentials: 'omit'`,
 * because the key is the credential and the user's cookies are not added;
 * `redirect: 'error'`, because a redirect would carry the key wherever it
 * points; and no address filter, because the user typed the URL into the
 * extension's own window, so a model server on localhost is allowed.
 *
 * A skill's secrets go out another way, in the skill's own `aero.fetch`
 * (background.js): the page leaves `{{env.NAME}}` in the request and names
 * the entry, and `fillSkillEnv` fills it in, for an approved host only. The
 * same reasons apply: no redirects, and a value never in the host.
 */

'use strict';

// Not even content scripts may read storage.local: only this worker and the
// extension's own pages. Set on every start, since nothing says it persists.
chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' }).catch(() => {});

const EXTENSION_ORIGIN = `chrome-extension://${chrome.runtime.id}`;

/** The kinds of entry, and what each fixes. */
const VAULT_KINDS = Object.assign(Object.create(null), {
  // One per origin, at a URL fixed here rather than typed: a request names a
  // path under it (`chat/completions`, `key`).
  openrouter: { title: 'OpenRouter key', fixedUrl: 'https://openrouter.ai/api/v1/', headers: false },
  // The URL is the endpoint, whole, and a request names no path.
  'custom-model': { title: 'Custom model', headers: true },
  mcp: { title: 'MCP server', headers: true },
  // One skill's secret env values: no URL of its own, but bound to hosts.
  // They are filled into that skill's own requests (`fillSkillEnv`), and
  // only those going to a host the user saw when typing them.
  'skill-env': { title: 'Skill secrets', headers: false, env: true },
});

const MAX_LABEL_CHARS = 120;
const MAX_META_BYTES = 16 * 1024;
const MAX_IMPORT_ITEMS = 32;
/** How long an unanswered form request is kept. */
const FORM_TTL_MS = 60 * 60 * 1000;
const HEADER_NAME_RE = /^[!#$%&'*+.^_`|~0-9A-Za-z-]+$/;
/** As src/api/skills.rs holds a skill's env var names and allowed hosts. */
const ENV_NAME_RE = /^[A-Z][A-Z0-9_]{0,63}$/;
const ALLOWED_HOST_RE = /^(\*\.)?[a-z0-9]([a-z0-9.-]*[a-z0-9])?(:\d{1,5})?$/;
const MAX_ENV_NAMES = 16;
const MAX_ENV_HOSTS = 16;
const ENV_PLACEHOLDER_RE = /\{\{env\.([A-Za-z_][A-Za-z0-9_]*)\}\}/g;

function errText(e) {
  return e && e.message ? e.message : String(e);
}

function hostOf(url) {
  try {
    return new URL(url).host;
  } catch {
    return '';
  }
}

// ---------------------------------------------------------------------------
// Storage. Mutations go one at a time: each is a read, a change and a write
// of the whole map, and two at once would lose one of them.

let vaultChain = Promise.resolve();

function withVaultLock(fn) {
  const run = vaultChain.then(fn, fn);
  vaultChain = run.then(
    () => {},
    () => {},
  );
  return run;
}

async function loadEntries() {
  const { vault } = await chrome.storage.local.get('vault');
  return vault && typeof vault === 'object' ? vault : {};
}

async function saveEntries(entries) {
  await chrome.storage.local.set({ vault: entries });
}

async function loadForms() {
  const { vaultForms } = await chrome.storage.session.get('vaultForms');
  return vaultForms && typeof vaultForms === 'object' ? vaultForms : {};
}

async function saveForms(forms) {
  await chrome.storage.session.set({ vaultForms: forms });
}

/** What a page may know about an entry: never its URL, key or header values. */
function summary(entry) {
  return {
    id: entry.id,
    kind: entry.kind,
    label: entry.label,
    host: hostOf(entry.url),
    endpoint: entry.endpoint || '',
    meta: entry.meta || {},
    hasSecret: !!entry.key || Object.keys(entry.headers || {}).length > 0,
    // Whether a sign-in is in force: null for an entry never signed in to.
    auth: entry.oauth ? (entry.oauth.accessToken ? 'signed-in' : 'signed-out') : null,
    // A skill's secrets: which have values, and the hosts they go to.
    ...(entry.kind === 'skill-env' ? { filled: Object.keys(entry.values || {}), hosts: entry.hosts || [] } : {}),
  };
}

/**
 * An endpoint's identity without its URL: the first 16 hex digits of its
 * SHA-256. Two entries at one URL share it, and it changes when the URL does,
 * which is what the app needs to know which model's thought signatures may go
 * where (`signatureProvider` in lib/ai.ts). It cannot be read back into the
 * URL, or a key in it.
 */
async function fingerprint(url) {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(url));
  return [...new Uint8Array(digest)]
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
    .slice(0, 16);
}

// ---------------------------------------------------------------------------
// Validation, shared by the window's save and a page's import.

function checkLabel(label) {
  if (typeof label !== 'string' || !label.trim() || label.length > MAX_LABEL_CHARS) {
    throw new Error(`vault_bad_request: a label is 1 to ${MAX_LABEL_CHARS} characters`);
  }
  return label.trim();
}

function checkMeta(meta) {
  if (meta == null) return {};
  if (typeof meta !== 'object' || Array.isArray(meta)) {
    throw new Error('vault_bad_request: meta is an object');
  }
  if (JSON.stringify(meta).length > MAX_META_BYTES) {
    throw new Error(`vault_bad_request: meta is over ${MAX_META_BYTES} bytes`);
  }
  return meta;
}

/** An endpoint the user gave, or an error a person can act on. */
function checkEndpoint(text, kind, meta) {
  let url;
  try {
    url = new URL(String(text || '').trim());
  } catch {
    throw new Error('The endpoint is not a URL.');
  }
  if (url.protocol !== 'https:' && url.protocol !== 'http:') {
    throw new Error('The endpoint has to be an http or https URL.');
  }
  // Gemini's other endpoints answer in one piece or as a JSON array, not as
  // the event stream Aero reads (lib/customModels.ts said this before the
  // URL moved here).
  if (
    kind === 'custom-model' &&
    meta &&
    meta.api === 'gemini' &&
    (!url.pathname.endsWith(':streamGenerateContent') || url.searchParams.get('alt') !== 'sse')
  ) {
    throw new Error("A Gemini endpoint is the model's streaming URL, ending in :streamGenerateContent?alt=sse.");
  }
  return url.href;
}

function checkKey(key) {
  const k = String(key || '').trim();
  if (!/^[\x21-\x7e]*$/.test(k)) {
    throw new Error('The key has a character keys never contain: check for a stray space or quote from the copy.');
  }
  return k;
}

/** The hosts in `hosts` that a skill's secrets `entry` was not saved for. */
function addedHosts(entry, hosts) {
  return hosts.filter((h) => !(entry.hosts || []).includes(h));
}

/** A skill's secrets' description from a page: the skill, its secret names, its hosts. */
function checkSkillEnvMeta(meta) {
  const m = checkMeta(meta);
  const names = Array.isArray(m.names) ? m.names.map(String) : [];
  const hosts = Array.isArray(m.hosts) ? m.hosts.map((h) => String(h).toLowerCase()) : [];
  if (typeof m.skillId !== 'string' || !m.skillId) throw new Error('vault_bad_request: skill secrets name their skill');
  if (names.length === 0 || names.length > MAX_ENV_NAMES || !names.every((n) => ENV_NAME_RE.test(n))) {
    throw new Error(`vault_bad_request: 1 to ${MAX_ENV_NAMES} env var names, in capitals`);
  }
  if (hosts.length > MAX_ENV_HOSTS || !hosts.every((h) => ALLOWED_HOST_RE.test(h))) {
    throw new Error('vault_bad_request: hosts as a skill lists them');
  }
  return { ...m, skillId: m.skillId, names, hosts };
}

function checkEnvValue(name, value) {
  const v = String(value ?? '');
  if (!/^[\x20-\x7e]*$/.test(v)) {
    throw new Error(`${name} has a character other than printable ASCII: check for a stray quote from the copy.`);
  }
  return v;
}

/** `Name: value` lines into lowercase names, as Settings has always read them. */
function parseHeadersText(text) {
  const headers = {};
  String(text || '')
    .split('\n')
    .forEach((raw, i) => {
      const line = raw.trim();
      if (!line) return;
      const colon = line.indexOf(':');
      const name = line.slice(0, colon).trim();
      const value = line.slice(colon + 1).trim();
      if (colon < 1 || !HEADER_NAME_RE.test(name)) {
        throw new Error(`Line ${i + 1} of the extra headers is not Name: value.`);
      }
      if (!/^[\x20-\x7e]*$/.test(value)) {
        throw new Error(`The ${name} header has a character other than printable ASCII: check for a stray quote from the copy.`);
      }
      headers[name.toLowerCase()] = value;
    });
  return headers;
}

function headersText(headers) {
  return Object.entries(headers || {})
    .map(([name, value]) => `${name}: ${value}`)
    .join('\n');
}

/**
 * The headers an entry adds to every request. The key goes in its format's
 * own header, and the extra headers come last: as in Settings before, a line
 * naming one of the format's headers replaces it.
 */
function secretHeaders(entry) {
  const out = {};
  if (entry.key) {
    const api = entry.kind === 'custom-model' && entry.meta ? entry.meta.api : null;
    if (api === 'anthropic') out['x-api-key'] = entry.key;
    else if (api === 'gemini') out['x-goog-api-key'] = entry.key;
    else out.authorization = `Bearer ${entry.key}`;
  }
  // A sign-in's token, where there is one, is the credential (see "Signing in").
  if (entry.oauth && entry.oauth.accessToken) out.authorization = `Bearer ${entry.oauth.accessToken}`;
  return Object.assign(out, entry.headers || {});
}

/** Where a request for `entry` goes: its own URL, or a path under a fixed one. */
function requestUrl(entry, path) {
  const kind = VAULT_KINDS[entry.kind];
  if (kind && kind.env) {
    throw new Error("vault_bad_request: a skill's secrets go into that skill's own requests, never alone");
  }
  if (kind && kind.fixedUrl) {
    const p = String(path || '');
    if (!/^[A-Za-z0-9][A-Za-z0-9/_.-]*$/.test(p) || p.split('/').some((s) => s === '..' || s === '.')) {
      throw new Error(`vault_bad_path: ${p || '(none)'}`);
    }
    return new URL(p, kind.fixedUrl).href;
  }
  if (path) throw new Error('vault_bad_path: this entry is called at its own URL, with no path');
  return entry.url;
}

// ---------------------------------------------------------------------------
// A page's requests about its own entries (`aero-vault`, through the
// dispatcher's trusted-origin gate in background.js).

async function vaultOp(req, origin) {
  switch (req && req.op) {
    case 'list': {
      const entries = Object.values(await loadEntries()).filter((e) => e.origin === origin);
      return { ok: true, result: entries.map(summary) };
    }
    case 'update':
      return withVaultLock(async () => {
        const entries = await loadEntries();
        const entry = entries[String(req.id)];
        if (!entry || entry.origin !== origin) return { ok: false, error: 'vault_entry_not_found' };
        if (req.label !== undefined) entry.label = checkLabel(req.label);
        if (req.meta !== undefined) entry.meta = checkMeta(req.meta);
        // The endpoint check reads meta (a Gemini URL's shape), so a format
        // change is checked against the URL already saved.
        checkEndpoint(entry.url, entry.kind, entry.meta);
        entry.updatedAt = Date.now();
        await saveEntries(entries);
        return { ok: true, result: summary(entry) };
      });
    case 'remove':
      return withVaultLock(async () => {
        const entries = await loadEntries();
        const entry = entries[String(req.id)];
        if (!entry || entry.origin !== origin) return { ok: false, error: 'vault_entry_not_found' };
        delete entries[entry.id];
        await saveEntries(entries);
        return { ok: true, result: null };
      });
    case 'edit':
      return openForm(origin, req);
    case 'import':
      return openImport(origin, req);
    case 'status':
      return formStatus(origin, String(req.requestId || ''));
    case 'signin':
      return startSignIn(origin, req);
    default:
      return { ok: false, error: 'vault_bad_request: unknown op' };
  }
}

/** A window for the user to type an entry's secrets into: new, or an edit. */
async function openForm(origin, req) {
  const kind = VAULT_KINDS[req.kind];
  if (!kind) return { ok: false, error: 'vault_bad_request: unknown kind' };
  const label = checkLabel(req.label);
  const meta = kind.env ? checkSkillEnvMeta(req.meta) : checkMeta(req.meta);
  const entries = await loadEntries();
  let entryId = req.id ? String(req.id) : null;
  if (entryId) {
    const entry = entries[entryId];
    if (!entry || entry.origin !== origin || entry.kind !== req.kind) {
      return { ok: false, error: 'vault_entry_not_found' };
    }
  } else if (kind.fixedUrl) {
    // One per origin: asking for a new one edits the one there is.
    const existing = Object.values(entries).find((e) => e.origin === origin && e.kind === req.kind);
    if (existing) entryId = existing.id;
  }
  return startForm({ mode: 'edit', origin, kind: req.kind, entryId, label, meta });
}

/** A window for the user to confirm moving secrets the page already holds. */
async function openImport(origin, req) {
  const items = Array.isArray(req.items) ? req.items : [];
  if (items.length === 0 || items.length > MAX_IMPORT_ITEMS) {
    return { ok: false, error: `vault_bad_request: import 1 to ${MAX_IMPORT_ITEMS} items` };
  }
  const checked = items.map((item) => {
    const kind = VAULT_KINDS[item && item.kind];
    if (!kind) throw new Error('vault_bad_request: unknown kind');
    if (kind.env) {
      const meta = checkSkillEnvMeta(item.meta);
      const values = {};
      for (const name of meta.names) {
        const v = item.values && item.values[name];
        if (v) values[name] = checkEnvValue(name, v);
      }
      return { kind: item.kind, label: checkLabel(item.label), url: '', key: '', headers: {}, values, hosts: meta.hosts, meta };
    }
    const meta = checkMeta(item.meta);
    return {
      kind: item.kind,
      label: checkLabel(item.label),
      url: kind.fixedUrl || checkEndpoint(item.url, item.kind, meta),
      key: checkKey(item.key),
      // As typed in Settings (`Name: value` lines), or already a map.
      headers: kind.headers
        ? parseHeadersText(typeof item.headers === 'string' ? item.headers : headersText(item.headers))
        : {},
      meta,
    };
  });
  return startForm({ mode: 'import', origin, items: checked });
}

/**
 * Record `form` and open its window: the extension's own form, or for a
 * sign-in, `url`, the authorization server's page.
 */
async function startForm(form, url) {
  const requestId = crypto.randomUUID();
  // Stored before the window opens, so its first question finds it.
  await withVaultLock(async () => {
    const forms = await loadForms();
    const now = Date.now();
    for (const [id, f] of Object.entries(forms)) if (now - f.createdAt > FORM_TTL_MS) delete forms[id];
    forms[requestId] = { ...form, requestId, status: 'pending', windowId: null, createdAt: now };
    await saveForms(forms);
  });
  const win = await chrome.windows.create({
    url: url || chrome.runtime.getURL(`secret.html#${requestId}`),
    type: 'popup',
    width: 520,
    height: url ? 760 : 660,
    focused: true,
  });
  await withVaultLock(async () => {
    const forms = await loadForms();
    if (forms[requestId]) forms[requestId].windowId = win.id;
    await saveForms(forms);
  });
  return { ok: true, result: { requestId } };
}

/** Whether the user has saved yet. Final answers are given once, then dropped. */
async function formStatus(origin, requestId) {
  return withVaultLock(async () => {
    const forms = await loadForms();
    const form = forms[requestId];
    if (!form || form.origin !== origin) return { ok: false, error: 'vault_form_not_found' };
    if (form.status === 'pending' && form.windowId != null) {
      // Closed with the window's own close button while this worker was
      // stopped, so `onRemoved` never ran.
      const open = await chrome.windows.get(form.windowId).then(
        () => true,
        () => false,
      );
      if (!open) form.status = 'cancelled';
    }
    // A sign-in whose code is being exchanged is still under way.
    if (form.status === 'pending' || form.status === 'exchanging') {
      return { ok: true, result: { status: 'pending' } };
    }
    delete forms[requestId];
    await saveForms(forms);
    if (form.status === 'failed') return { ok: true, result: { status: 'failed', error: form.error } };
    if (form.status !== 'saved') return { ok: true, result: { status: form.status } };
    const entries = await loadEntries();
    const saved = (form.savedIds || []).map((id) => entries[id]).filter(Boolean);
    return { ok: true, result: { status: 'saved', entries: saved.map(summary) } };
  });
}

chrome.windows.onRemoved.addListener((windowId) => {
  withVaultLock(async () => {
    const forms = await loadForms();
    let changed = false;
    for (const f of Object.values(forms)) {
      if (f.windowId === windowId && f.status === 'pending') {
        f.status = 'cancelled';
        changed = true;
      }
    }
    if (changed) await saveForms(forms);
  });
});

// ---------------------------------------------------------------------------
// The window's own requests (secret.js). Only the extension's own pages get
// here: background.js routes by `sender.origin`, which a page cannot fake.

async function vaultWindowOp(msg) {
  const requestId = String(msg.requestId || '');
  switch (msg.type) {
    case 'vault-form-get': {
      const form = (await loadForms())[requestId];
      if (!form || form.status !== 'pending') return { ok: false, error: 'This request is no longer open.' };
      if (form.mode === 'import') {
        return {
          ok: true,
          form: {
            mode: 'import',
            origin: form.origin,
            items: form.items.map((i) => ({
              label: i.label,
              kindTitle: VAULT_KINDS[i.kind].title,
              url: i.url,
              hasKey: !!i.key || Object.keys(i.values || {}).length > 0,
              headerNames: Object.keys(i.headers),
              ...(VAULT_KINDS[i.kind].env ? { envNames: Object.keys(i.values), hosts: i.hosts } : {}),
            })),
          },
        };
      }
      const kind = VAULT_KINDS[form.kind];
      const entry = form.entryId ? (await loadEntries())[form.entryId] : null;
      if (kind.env) {
        const added = entry ? addedHosts(entry, form.meta.hosts) : [];
        return {
          ok: true,
          form: {
            mode: 'edit',
            env: true,
            origin: form.origin,
            kindTitle: kind.title,
            label: form.label,
            names: form.meta.names,
            hosts: form.meta.hosts,
            // With a host added, nothing saved is kept: see the save below.
            existing: entry ? { filled: added.length ? [] : Object.keys(entry.values || {}), addedHosts: added } : null,
          },
        };
      }
      return {
        ok: true,
        form: {
          mode: 'edit',
          origin: form.origin,
          kindTitle: kind.title,
          label: form.label,
          fixedUrl: kind.fixedUrl || null,
          allowsHeaders: kind.headers,
          existing: entry ? { url: entry.url, headersText: headersText(entry.headers), hasKey: !!entry.key } : null,
        },
      };
    }
    case 'vault-form-save':
      return withVaultLock(async () => {
        const forms = await loadForms();
        const form = forms[requestId];
        if (!form || form.status !== 'pending') return { ok: false, error: 'This request is no longer open.' };
        const entries = await loadEntries();
        const saved = [];
        try {
          if (form.mode === 'import') {
            for (const item of form.items) {
              const id = crypto.randomUUID();
              const endpoint = item.url ? await fingerprint(item.url) : '';
              entries[id] = { id, origin: form.origin, ...item, endpoint, updatedAt: Date.now() };
              saved.push(id);
            }
          } else if (VAULT_KINDS[form.kind].env) {
            const existing = form.entryId ? entries[form.entryId] : null;
            const id = existing ? existing.id : crypto.randomUUID();
            const typed = (msg.values && msg.values.env) || {};
            // Left empty, a value saved before is kept, but only while it
            // would go nowhere new. Otherwise a page could list a host of
            // its own and need from the user no more than a click on Save.
            const kept = existing && addedHosts(existing, form.meta.hosts).length === 0 ? existing.values || {} : {};
            const values = {};
            for (const name of form.meta.names) {
              const v = checkEnvValue(name, typed[name]);
              if (v) values[name] = v;
              else if (kept[name]) values[name] = kept[name];
            }
            entries[id] = {
              id,
              origin: form.origin,
              kind: form.kind,
              label: form.label,
              url: '',
              endpoint: '',
              key: '',
              headers: {},
              values,
              // The hosts the user saw as they typed: the only ones these go to.
              hosts: form.meta.hosts,
              meta: form.meta,
              updatedAt: Date.now(),
            };
            saved.push(id);
          } else {
            const kind = VAULT_KINDS[form.kind];
            const values = msg.values || {};
            const existing = form.entryId ? entries[form.entryId] : null;
            const id = existing ? existing.id : crypto.randomUUID();
            const typedKey = checkKey(values.key);
            const url = kind.fixedUrl || checkEndpoint(values.url, form.kind, form.meta);
            entries[id] = {
              id,
              origin: form.origin,
              kind: form.kind,
              label: form.label,
              url,
              endpoint: await fingerprint(url),
              // Left empty on an edit, the key is kept rather than cleared.
              key: typedKey || (existing ? existing.key : ''),
              headers: kind.headers ? parseHeadersText(values.headersText) : {},
              meta: form.meta,
              // A sign-in is to one server: kept while the URL is, dropped
              // when it changes, since its tokens name the old one.
              ...(existing && existing.oauth && existing.url === url ? { oauth: existing.oauth } : {}),
              updatedAt: Date.now(),
            };
            saved.push(id);
          }
        } catch (e) {
          return { ok: false, error: errText(e) };
        }
        await saveEntries(entries);
        form.status = 'saved';
        form.savedIds = saved;
        await saveForms(forms);
        return { ok: true };
      });
    case 'vault-form-cancel':
      return withVaultLock(async () => {
        const forms = await loadForms();
        if (forms[requestId] && forms[requestId].status === 'pending') {
          forms[requestId].status = 'cancelled';
          await saveForms(forms);
        }
        return { ok: true };
      });
    default:
      return { ok: false, error: 'unknown request' };
  }
}

// ---------------------------------------------------------------------------
// Signing in, for an MCP server that wants OAuth rather than a key.
//
// The MCP authorization spec (2026-07-28), run here end to end, so no token
// reaches a page:
//   1. Discovery. A request without credentials answers 401 with
//      `WWW-Authenticate: Bearer resource_metadata="…"`. That document (RFC
//      9728; its well-known path when the header names none) names the
//      authorization server, whose own metadata (RFC 8414, else OpenID
//      Connect discovery) gives its endpoints.
//   2. Who Aero is. A Client ID Metadata Document where the authorization
//      server takes one and the page is on HTTPS: the client id is the URL
//      `<origin>/mcp-client.json`, which Aero serves (src/mcp_client_meta.rs).
//      Else dynamic registration, kept with the entry for that authorization
//      server. A server that offers neither wants an app registered by hand,
//      which this does not do; such servers usually take a key as well.
//   3. The sign-in, in a window of its own: authorization code with PKCE
//      (S256), `state`, and `resource` naming the server, as the spec
//      requires. It comes back to `<origin>/mcp-callback.html`, a page with
//      no script: the code is read off the tab's URL as it lands, and the
//      window closed. The `iss` it carries is checked against the server
//      asked (RFC 9207); a `state` that matches no sign-in under way is not
//      ours and is left alone.
//   4. Tokens are exchanged and refreshed here, kept in the entry, and sent as
//      `Authorization: Bearer`. One about to expire, or one the server
//      refuses with a 401, is refreshed once; a refresh the authorization
//      server refuses leaves the entry signed out, and the page offers the
//      sign-in again.
// A sign-in under way keeps its state (verifier, endpoints) in
// storage.session with the forms, so a worker stopped mid-way loses nothing.

const CALLBACK_PATH = '/mcp-callback.html';
const CLIENT_METADATA_PATH = '/mcp-client.json';
/** Refresh a token this close to its expiry rather than send it. */
const REFRESH_MARGIN_MS = 60 * 1000;

function b64url(bytes) {
  let bin = '';
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function randomToken() {
  return b64url(crypto.getRandomValues(new Uint8Array(32)));
}

async function pkcePair() {
  const verifier = randomToken();
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier));
  return { verifier, challenge: b64url(new Uint8Array(digest)) };
}

/** One `name="value"` (or bare `name=value`) out of a WWW-Authenticate header. */
function challengeParam(header, name) {
  const m = new RegExp(`${name}\\s*=\\s*(?:"([^"]*)"|([^\\s,]+))`, 'i').exec(header || '');
  return m ? m[1] ?? m[2] : null;
}

/** RFC 9728's well-known URLs for a resource: path-inserted first, then the root. */
function protectedResourceUrls(resource) {
  const u = new URL(resource);
  const path = u.pathname.replace(/\/+$/, '');
  const base = `${u.origin}/.well-known/oauth-protected-resource`;
  return path ? [base + path, base] : [base];
}

/** RFC 8414 path-inserted, then OpenID Connect's two spellings. */
function authServerMetadataUrls(issuer) {
  const u = new URL(issuer);
  const path = u.pathname.replace(/\/+$/, '');
  if (!path) return [`${u.origin}/.well-known/oauth-authorization-server`, `${u.origin}/.well-known/openid-configuration`];
  return [
    `${u.origin}/.well-known/oauth-authorization-server${path}`,
    `${u.origin}/.well-known/openid-configuration${path}`,
    `${u.origin}${path}/.well-known/openid-configuration`,
  ];
}

/** The first of `urls` that answers with a JSON object. */
async function firstJson(urls) {
  for (const url of urls) {
    if (!url) continue;
    try {
      const res = await fetch(url, { headers: { accept: 'application/json' }, credentials: 'omit' });
      if (!res.ok) continue;
      const body = await res.json();
      if (body && typeof body === 'object') return body;
    } catch {
      // The next spelling, if any.
    }
  }
  return null;
}

/** How `entry`'s server wants signing in: its authorization server, endpoints and scope. */
async function discoverAuth(entry) {
  let challenge = '';
  try {
    const probe = await fetch(entry.url, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        accept: 'application/json, text/event-stream',
        'MCP-Protocol-Version': '2026-07-28',
        'Mcp-Method': 'tools/list',
      },
      body: JSON.stringify({ jsonrpc: '2.0', id: 0, method: 'tools/list', params: {} }),
      credentials: 'omit',
      redirect: 'error',
    });
    challenge = probe.headers.get('www-authenticate') || '';
  } catch {
    // Unreachable: the well-known paths below may still answer.
  }
  const prm = await firstJson([challengeParam(challenge, 'resource_metadata'), ...protectedResourceUrls(entry.url)]);
  const issuer = prm && Array.isArray(prm.authorization_servers) ? prm.authorization_servers[0] : null;
  if (typeof issuer !== 'string' || !issuer) {
    throw new Error('This server does not say how to sign in to it: give it a key instead, if it takes one.');
  }
  const as = await firstJson(authServerMetadataUrls(issuer));
  if (!as || typeof as.authorization_endpoint !== 'string' || typeof as.token_endpoint !== 'string') {
    throw new Error(`The sign-in server ${hostOf(issuer)} does not publish its endpoints.`);
  }
  // RFC 8414: metadata fetched for one issuer must name that issuer.
  if (as.issuer && as.issuer !== issuer) throw new Error(`The sign-in server ${hostOf(issuer)} names another issuer.`);
  let scope = challengeParam(challenge, 'scope') || (Array.isArray(prm.scopes_supported) ? prm.scopes_supported.join(' ') : '');
  // Without it many servers issue no refresh token, and the sign-in lasts an hour.
  if (Array.isArray(as.scopes_supported) && as.scopes_supported.includes('offline_access') && !/\boffline_access\b/.test(scope)) {
    scope = scope ? `${scope} offline_access` : 'offline_access';
  }
  return {
    issuer,
    authorizationEndpoint: as.authorization_endpoint,
    tokenEndpoint: as.token_endpoint,
    registrationEndpoint: typeof as.registration_endpoint === 'string' ? as.registration_endpoint : null,
    cimd: as.client_id_metadata_document_supported === true,
    issParam: as.authorization_response_iss_parameter_supported === true,
    resource: typeof prm.resource === 'string' && prm.resource ? prm.resource : entry.url,
    scope,
  };
}

/** Aero as this authorization server knows it: by metadata document, a kept registration, or a new one. */
async function clientFor(entry, auth) {
  const redirectUri = `${entry.origin}${CALLBACK_PATH}`;
  const kept = entry.oauth;
  if (kept && kept.issuer === auth.issuer && kept.clientId && kept.redirectUri === redirectUri) {
    return { clientId: kept.clientId, clientSecret: kept.clientSecret || null, authMethod: kept.authMethod || 'none', redirectUri };
  }
  // The metadata document has to be an HTTPS URL, so a local dev origin registers instead.
  if (auth.cimd && entry.origin.startsWith('https://')) {
    return { clientId: `${entry.origin}${CLIENT_METADATA_PATH}`, clientSecret: null, authMethod: 'none', redirectUri };
  }
  if (!auth.registrationEndpoint) {
    throw new Error(
      `${hostOf(auth.issuer)} wants an app registered with it by hand, which Aero Helper does not do: ` +
        'give the server a key instead, if it takes one.',
    );
  }
  const local = /^http:\/\/(localhost|127\.0\.0\.1)(:|$)/.test(entry.origin);
  const res = await fetch(auth.registrationEndpoint, {
    method: 'POST',
    headers: { 'content-type': 'application/json', accept: 'application/json' },
    body: JSON.stringify({
      client_name: 'Aero',
      client_uri: entry.origin,
      redirect_uris: [redirectUri],
      grant_types: ['authorization_code', 'refresh_token'],
      response_types: ['code'],
      token_endpoint_auth_method: 'none',
      // The spec asks for the type: a page on localhost is a native app to OIDC.
      application_type: local ? 'native' : 'web',
    }),
    credentials: 'omit',
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok || typeof body.client_id !== 'string') {
    throw new Error(`${hostOf(auth.issuer)} refused to register Aero (${body.error_description || body.error || `HTTP ${res.status}`}).`);
  }
  const client = {
    clientId: body.client_id,
    clientSecret: typeof body.client_secret === 'string' ? body.client_secret : null,
    authMethod: body.token_endpoint_auth_method || (body.client_secret ? 'client_secret_post' : 'none'),
    redirectUri,
  };
  // Kept for the next sign-in to the same authorization server.
  await withVaultLock(async () => {
    const entries = await loadEntries();
    const e = entries[entry.id];
    if (!e) return;
    e.oauth = { issuer: auth.issuer, ...client, accessToken: null, refreshToken: null, expiresAt: null };
    await saveEntries(entries);
  });
  return client;
}

/** A token request; resolves with the tokens, or rejects with the server's own words. */
async function tokenRequest(oauth, params) {
  const body = new URLSearchParams({ ...params, client_id: oauth.clientId, resource: oauth.resource });
  const headers = { 'content-type': 'application/x-www-form-urlencoded', accept: 'application/json' };
  if (oauth.clientSecret) {
    if (oauth.authMethod === 'client_secret_basic') {
      headers.authorization = `Basic ${btoa(`${encodeURIComponent(oauth.clientId)}:${encodeURIComponent(oauth.clientSecret)}`)}`;
      body.delete('client_id');
    } else {
      body.set('client_secret', oauth.clientSecret);
    }
  }
  const res = await fetch(oauth.tokenEndpoint, { method: 'POST', headers, body, credentials: 'omit', redirect: 'error' });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || typeof json.access_token !== 'string') {
    const err = new Error(json.error_description || json.error || `HTTP ${res.status}`);
    err.code = json.error;
    throw err;
  }
  return {
    accessToken: json.access_token,
    refreshToken: typeof json.refresh_token === 'string' ? json.refresh_token : null,
    expiresAt: typeof json.expires_in === 'number' ? Date.now() + json.expires_in * 1000 : null,
  };
}

/** A page asks to sign in to one of its MCP entries: open the authorization server's page. */
async function startSignIn(origin, req) {
  const entry = (await loadEntries())[String(req.id)];
  if (!entry || entry.origin !== origin || entry.kind !== 'mcp') return { ok: false, error: 'vault_entry_not_found' };
  const auth = await discoverAuth(entry);
  const client = await clientFor(entry, auth);
  const { verifier, challenge } = await pkcePair();
  const state = randomToken();
  const url = new URL(auth.authorizationEndpoint);
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('client_id', client.clientId);
  url.searchParams.set('redirect_uri', client.redirectUri);
  url.searchParams.set('code_challenge', challenge);
  url.searchParams.set('code_challenge_method', 'S256');
  url.searchParams.set('state', state);
  url.searchParams.set('resource', auth.resource);
  if (auth.scope) url.searchParams.set('scope', auth.scope);
  return startForm({ mode: 'signin', origin, entryId: entry.id, state, verifier, auth, client }, url.href);
}

/** A tab landed on a callback: if it answers a sign-in under way, finish that sign-in. */
async function finishSignIn(tabId, rawUrl) {
  let u;
  try {
    u = new URL(rawUrl);
  } catch {
    return;
  }
  const state = u.searchParams.get('state');
  if (!state) return;
  const form = await withVaultLock(async () => {
    const forms = await loadForms();
    const f = Object.values(forms).find((x) => x.mode === 'signin' && x.status === 'pending' && x.state === state);
    if (!f || `${u.origin}${u.pathname}` !== f.client.redirectUri) return null;
    // Claimed before the window closes, so closing it does not read as a cancel.
    f.status = 'exchanging';
    await saveForms(forms);
    return f;
  });
  if (!form) return;
  chrome.windows.remove(form.windowId).catch(() => chrome.tabs.remove(tabId).catch(() => {}));

  let tokens = null;
  let failure = null;
  try {
    const iss = u.searchParams.get('iss');
    if (form.auth.issParam && !iss) throw new Error('The sign-in came back without naming its server, which that server promised to do.');
    if (iss && iss !== form.auth.issuer) throw new Error('The sign-in came back from a different server than the one asked.');
    const error = u.searchParams.get('error');
    if (error) throw new Error(u.searchParams.get('error_description') || error);
    const code = u.searchParams.get('code');
    if (!code) throw new Error('The sign-in came back without a code.');
    tokens = await tokenRequest(
      { ...form.client, tokenEndpoint: form.auth.tokenEndpoint, resource: form.auth.resource },
      { grant_type: 'authorization_code', code, redirect_uri: form.client.redirectUri, code_verifier: form.verifier },
    );
  } catch (e) {
    failure = errText(e);
  }

  await withVaultLock(async () => {
    const forms = await loadForms();
    const f = forms[form.requestId];
    if (!f) return;
    const entries = await loadEntries();
    const entry = entries[f.entryId];
    if (!failure && !entry) failure = 'The server was removed while signing in.';
    if (failure) {
      f.status = 'failed';
      f.error = failure;
    } else {
      entry.oauth = {
        issuer: f.auth.issuer,
        tokenEndpoint: f.auth.tokenEndpoint,
        resource: f.auth.resource,
        ...f.client,
        ...tokens,
      };
      entry.updatedAt = Date.now();
      await saveEntries(entries);
      f.status = 'saved';
      f.savedIds = [entry.id];
    }
    await saveForms(forms);
  });
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.url && changeInfo.url.includes(CALLBACK_PATH)) finishSignIn(tabId, changeInfo.url);
});

/**
 * `entryId`'s sign-in with fresh tokens: refreshed if `force`, or if within a
 * minute of expiring. A refresh the server refuses signs the entry out.
 * Resolves with the entry as it now stands.
 */
async function refreshSignIn(entryId, force) {
  return withVaultLock(async () => {
    const entries = await loadEntries();
    const entry = entries[entryId];
    const o = entry && entry.oauth;
    if (!o || !o.refreshToken) return entry;
    const due = o.expiresAt != null && o.expiresAt - Date.now() < REFRESH_MARGIN_MS;
    if (!force && !due) return entry;
    try {
      const tokens = await tokenRequest(o, { grant_type: 'refresh_token', refresh_token: o.refreshToken });
      // A server that rotates refresh tokens sends a new one; one that doesn't, keeps the old.
      entry.oauth = { ...o, ...tokens, refreshToken: tokens.refreshToken || o.refreshToken };
    } catch (e) {
      // Refused (revoked, expired): signed out. Unreachable: left as it was.
      if (e && e.code) entry.oauth = { ...o, accessToken: null, refreshToken: null, expiresAt: null };
      else return entry;
    }
    entry.updatedAt = Date.now();
    await saveEntries(entries);
    return entry;
  });
}

// ---------------------------------------------------------------------------
// A skill's secrets, filled into its own requests (background.js's
// `aero-fetch`). The page leaves `{{env.NAME}}` in place for each secret and
// names the entry; the values are put in here, and only for a request whose
// host is one the user saw when typing them. A skill whose owner adds a host
// later gets the secrets there only once the user has typed them again with
// that host shown. A placeholder in the host itself is refused, so a value
// can never choose where it goes.

async function fillSkillEnv(req, origin) {
  if (!req.envEntryId) return req;
  const entry = (await loadEntries())[String(req.envEntryId)];
  if (!entry || entry.origin !== origin || entry.kind !== 'skill-env') {
    throw new Error("missing_env: this skill's secrets are not saved in Aero Helper: enter them from the Skills page");
  }
  let url;
  try {
    url = new URL(String(req.url || ''));
  } catch {
    throw new Error('invalid_url: ' + req.url);
  }
  if (/\{\{|%7b%7b/i.test(url.host)) throw new Error('env_in_host: a secret may not name the host it goes to');
  const host = url.hostname.toLowerCase();
  const port = url.port ? Number(url.port) : url.protocol === 'http:' ? 80 : 443;
  if (!hostAllowed(host, port, entry.hosts || [])) {
    throw new Error(
      `env_host_not_approved: this skill's secrets go only to ${(entry.hosts || []).join(', ') || 'no host'}, ` +
        `and ${host} is not one of them. Enter them again from the Skills page to approve its hosts as they are now.`,
    );
  }
  const missing = [];
  const fill = (text) =>
    String(text).replace(ENV_PLACEHOLDER_RE, (match, name) => {
      if (entry.values && Object.prototype.hasOwnProperty.call(entry.values, name)) return entry.values[name];
      if (!missing.includes(name)) missing.push(name);
      return match;
    });
  const headers = {};
  for (const [k, v] of Object.entries(req.headers || {})) headers[k] = fill(v);
  const filled = {
    ...req,
    url: fill(req.url),
    headers,
    body: req.body == null ? req.body : fill(req.body),
    // A header carrying a secret would follow a redirect to another host.
    noRedirect: true,
  };
  if (missing.length) {
    throw new Error(`missing_env: ${missing.join(', ')}: enter them in Aero Helper from the Skills page`);
  }
  return filled;
}

// ---------------------------------------------------------------------------
// Requests made with an entry: one port per request, from content.js.

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'vault-fetch') return;
  if (!port.sender || port.sender.id !== chrome.runtime.id) {
    port.disconnect();
    return;
  }
  const origin = senderOrigin(port.sender);
  const controller = new AbortController();
  let started = false;
  // The page cancelled (its Stop button), or went away: stop the request too.
  port.onDisconnect.addListener(() => controller.abort());
  port.onMessage.addListener((msg) => {
    if (!msg) return;
    // content.js pings every 20s while a request is open, and the answer is
    // what keeps this worker running: Chrome stops it after 30s with nothing
    // to do, and waiting on a slow first byte counts as nothing (measured
    // 2026-11-08: answers 70s and 150s in were cut off at 30s without this,
    // and completed with it).
    if (msg.type === 'keepalive') {
      try {
        port.postMessage({ type: 'keepalive' });
      } catch {
        // Already gone.
      }
      return;
    }
    if (started || msg.type !== 'request') return;
    started = true;
    vaultFetch(port, origin, msg.req || {}, controller.signal);
  });
});

async function vaultFetch(port, origin, req, signal) {
  const send = (m) => {
    try {
      port.postMessage(m);
    } catch {
      // The page went away; the abort above ends the request.
    }
  };
  try {
    if (!(await isTrusted(origin))) throw new Error(notTrustedError(origin));
    let entry = (await loadEntries())[String(req.id)];
    if (!entry || entry.origin !== origin) {
      throw new Error(`vault_entry_not_found: Aero Helper holds no such key for ${origin}`);
    }
    const url = requestUrl(entry, req.path);
    const method = String(req.method || 'POST').toUpperCase();
    if (!['GET', 'POST', 'DELETE'].includes(method)) throw new Error(`vault_bad_request: method ${method}`);
    if (req.body != null && typeof req.body !== 'string') throw new Error('vault_bad_request: body is a string');

    const pageHeaders = new Headers();
    for (const [name, value] of Object.entries(req.headers || {})) {
      const lower = name.toLowerCase();
      // The entry is the only source of credentials.
      if (!HEADER_NAME_RE.test(name) || FORBIDDEN_HEADERS.has(lower) || lower === 'authorization') continue;
      pageHeaders.set(name, String(value));
    }
    const attempt = async (e) => {
      const headers = new Headers(pageHeaders);
      for (const [name, value] of Object.entries(secretHeaders(e))) headers.set(name, value);
      try {
        return await fetch(url, {
          method,
          headers,
          body: method === 'GET' ? undefined : req.body,
          credentials: 'omit',
          redirect: 'error',
          signal,
        });
      } catch (err) {
        if (signal.aborted) throw err;
        throw new Error(
          `vault_unreachable: ${hostOf(url)} could not be reached, or answered with a redirect, ` +
            'which a request carrying a key does not follow',
        );
      }
    };

    // A sign-in's token about to expire is refreshed before it is sent, and
    // one the server refuses is refreshed once and the request sent again.
    if (entry.oauth && entry.oauth.accessToken) entry = await refreshSignIn(entry.id, false);
    let resp = await attempt(entry);
    if (resp.status === 401 && entry.oauth && entry.oauth.refreshToken) {
      const refreshed = await refreshSignIn(entry.id, true);
      if (refreshed && refreshed.oauth && refreshed.oauth.accessToken) {
        await resp.body?.cancel();
        resp = await attempt(refreshed);
      }
    }
    const respHeaders = {};
    resp.headers.forEach((v, k) => {
      respHeaders[k] = v;
    });
    send({ type: 'head', status: resp.status, statusText: resp.statusText, headers: respHeaders });
    if (resp.body) {
      const reader = resp.body.pipeThrough(new TextDecoderStream()).getReader();
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        if (value) send({ type: 'chunk', text: value });
      }
    }
    send({ type: 'end' });
  } catch (e) {
    if (!signal.aborted) send({ type: 'error', message: errText(e) });
  } finally {
    try {
      port.disconnect();
    } catch {
      // Already gone.
    }
  }
}
