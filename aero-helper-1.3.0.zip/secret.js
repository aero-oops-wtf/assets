/**
 * Aero Helper — the vault's window, where the user types a secret (vault.js).
 *
 * An Aero page asked the worker to open it, for a new entry, an edit, or to
 * confirm moving keys the page already held. Everything shown comes from the
 * worker, keyed by the request id in this page's hash; what the user types
 * goes straight back to the worker and never to the page that asked, which
 * learns only whether the user saved.
 */

'use strict';

var requestId = location.hash.slice(1);
var form = null;

function $(id) {
  return document.getElementById(id);
}

function hostOf(text) {
  try {
    return new URL(text.trim()).host;
  } catch (e) {
    return '';
  }
}

function showDest() {
  var host = hostOf($('url').value);
  $('dest').textContent = '';
  if (!host) return;
  $('dest').append('Requests with this key go to ');
  var strong = document.createElement('strong');
  strong.textContent = host;
  $('dest').append(strong, ' and nowhere else.');
}

function renderEdit(f) {
  document.title = 'Aero Helper — ' + f.kindTitle;
  $('title').textContent = f.existing ? 'Change a saved key' : 'Save a key';
  $('intro').textContent =
    f.origin + ' can use what you save here to make requests to its endpoint. It can’t read it back.';
  $('kind').textContent = f.kindTitle;
  $('label').textContent = f.label;
  if (f.fixedUrl) {
    $('url').hidden = true;
    $('fixed-url').hidden = false;
    $('fixed-url').querySelector('code').textContent = f.fixedUrl;
    $('url').value = f.fixedUrl;
  } else if (f.existing) {
    $('url').value = f.existing.url;
  }
  showDest();
  $('url').addEventListener('input', showDest);
  $('key').placeholder =
    f.existing && f.existing.hasKey ? 'Saved — type a new one to replace it' : 'Leave empty if the endpoint wants none';
  $('headers-block').hidden = !f.allowsHeaders;
  if (f.existing) $('headers').value = f.existing.headersText;
  $('edit').hidden = false;
  (f.fixedUrl ? $('key') : $('url')).focus();
}

/** A skill's secrets: a field for each, and the hosts they will go to. */
function renderEnv(f) {
  document.title = 'Aero Helper \u2014 ' + f.kindTitle;
  $('title').textContent = f.existing ? 'Change a skill\u2019s secrets' : 'Save a skill\u2019s secrets';
  $('intro').textContent =
    f.origin + ' can have these put into the skill\u2019s requests to the hosts below. It can\u2019t read them back.';
  $('env-kind').textContent = f.kindTitle;
  $('env-label').textContent = f.label;
  var filled = (f.existing && f.existing.filled) || [];
  f.names.forEach(function (name) {
    var field = document.createElement('div');
    var label = document.createElement('label');
    label.setAttribute('for', 'env-' + name);
    label.className = 'mono';
    label.textContent = name;
    var input = document.createElement('input');
    input.id = 'env-' + name;
    input.type = 'password';
    input.autocomplete = 'off';
    input.spellcheck = false;
    input.dataset.name = name;
    input.placeholder = filled.indexOf(name) >= 0 ? 'Saved \u2014 type a new one to replace it' : 'Not set';
    field.append(label, input);
    $('env-fields').append(field);
  });
  $('env-dest').textContent = '';
  if (f.hosts.length) {
    $('env-dest').append('They go only to ');
    var strong = document.createElement('strong');
    strong.textContent = f.hosts.join(', ');
    $('env-dest').append(strong, '.');
    var added = (f.existing && f.existing.addedHosts) || [];
    if (added.length) {
      var neu = document.createElement('strong');
      neu.textContent = added.join(', ');
      $('env-dest').append(' New since you saved them: ', neu, ', so type every one again to send it there.');
    }
  } else {
    $('env-dest').textContent = 'The skill lists no hosts, so they go nowhere until it does and you save them again.';
  }
  $('env').hidden = false;
  var first = $('env-fields').querySelector('input');
  if (first) first.focus();
}

function renderImport(f) {
  $('title').textContent = 'Move keys into Aero Helper';
  $('intro').textContent =
    f.origin + ' wants to move these into Aero Helper. Each will be sent only to the address shown, ' +
    'and the page will no longer be able to read it.';
  f.items.forEach(function (item) {
    var li = document.createElement('li');
    li.className = 'row stack';
    var head = document.createElement('div');
    head.className = 'row-head';
    var strong = document.createElement('strong');
    strong.textContent = item.label;
    var kind = document.createElement('span');
    kind.className = 'eyebrow';
    kind.textContent = item.kindTitle;
    head.append(strong, kind);
    var url = document.createElement('code');
    var what = document.createElement('div');
    what.className = 'note';
    if (item.envNames) {
      // A skill's secrets have no address of their own: where they may go.
      url.textContent = item.hosts.length ? 'Only to ' + item.hosts.join(', ') : 'To no host yet';
      what.className = 'note mono';
      what.textContent = item.envNames.join(', ');
    } else {
      url.textContent = item.url;
      what.textContent =
        (item.hasKey ? 'With its key' : 'No key') +
        (item.headerNames.length ? ', and headers: ' + item.headerNames.join(', ') : '');
    }
    li.append(head, url, what);
    $('items').appendChild(li);
  });
  $('save').textContent = 'Move ' + (f.items.length === 1 ? 'it' : 'all ' + f.items.length);
  $('import').hidden = false;
}

/**
 * One question to the worker. A failure (the extension reloaded under this
 * window, say) comes back as an answer with its error, so no handler is left
 * with Save disabled or the window unable to close.
 */
async function ask(msg) {
  msg.requestId = requestId;
  try {
    return await chrome.runtime.sendMessage(msg);
  } catch (e) {
    return { ok: false, error: 'Aero Helper could not be reached (' + (e && e.message ? e.message : String(e)) + '). Close this window and try again.' };
  }
}

$('save').addEventListener('click', async function () {
  // Disabled until the form loads (secret.html), but a request whose window
  // was left open can be gone by the time Save is pressed.
  if (!form) return;
  $('error').textContent = '';
  $('save').disabled = true;
  var values = {};
  if (form.mode === 'edit' && form.env) {
    values.env = {};
    $('env-fields').querySelectorAll('input').forEach(function (input) {
      values.env[input.dataset.name] = input.value;
    });
  } else if (form.mode === 'edit') {
    values = { url: $('url').value, key: $('key').value, headersText: $('headers').value };
  }
  var reply = await ask({ type: 'vault-form-save', values: values });
  $('save').disabled = false;
  if (reply && reply.ok) window.close();
  else $('error').textContent = (reply && reply.error) || 'Aero Helper could not save it.';
});

// Enter in a field means Save; in the headers box it is a new line. Not left
// to the browser: a form with one field submits itself, which reloads this
// window without the request id in its hash, and the request with it; and a
// form with more, having no submit button, does nothing at all.
['env', 'edit'].forEach(function (id) {
  $(id).addEventListener('keydown', function (ev) {
    if (ev.key !== 'Enter' || ev.isComposing || ev.target.tagName !== 'INPUT') return;
    ev.preventDefault();
    if (!$('save').disabled) $('save').click();
  });
});

$('cancel').addEventListener('click', async function () {
  await ask({ type: 'vault-form-cancel' });
  window.close();
});

ask({ type: 'vault-form-get' }).then(function (reply) {
  if (!reply || !reply.ok) {
    $('intro').textContent = (reply && reply.error) || 'This request is no longer open.';
    $('save').hidden = true;
    return;
  }
  form = reply.form;
  $('save').disabled = false;
  if (form.mode === 'import') renderImport(form);
  else if (form.env) renderEnv(form);
  else renderEdit(form);
});
