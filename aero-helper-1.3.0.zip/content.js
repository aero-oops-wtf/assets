/**
 * Aero Helper — content script.
 *
 * Injected on all pages (see content_scripts.matches in manifest.json) but
 * stays DORMANT until it detects Aero's meta marker in the DOM:
 *   <meta name="aero-oops-wtf" content="true">
 * (see frontend/index.html). Non-Aero pages never see the hello, can't
 * trigger fetches, and the script costs nothing but a meta-tag check.
 *
 * Bridges the page to the background service worker:
 *   page ── window.postMessage ──▶ content ── runtime.sendMessage ──▶ background
 *   page ◀─ window.postMessage ── content ◀───────── response ────── background
 *
 * Protocol (all messages carry a `source` tag so unrelated postMessage
 * traffic is ignored):
 *   page → helper : { source: 'aero-oops-wtf-page',   type: 'ping' }
 *   page → helper : { source: 'aero-oops-wtf-page',   type: 'fetch',  id, req }
 *   page → helper : { source: 'aero-oops-wtf-page',   type: 'browse', id, req }
 *   page → helper : { source: 'aero-oops-wtf-page',   type: 'vault',  id, req }
 *   page → helper : { source: 'aero-oops-wtf-page',   type: 'vault-fetch',  id, req }
 *   page → helper : { source: 'aero-oops-wtf-page',   type: 'vault-cancel', id }
 *   helper → page : { source: 'aero-oops-wtf-helper', type: 'hello', version, trusted }
 *   helper → page : { source: 'aero-oops-wtf-helper', type: 'fetch-result',  id, ok, response?, error? }
 *   helper → page : { source: 'aero-oops-wtf-helper', type: 'browse-result', id, ok, result?,   error? }
 *   helper → page : { source: 'aero-oops-wtf-helper', type: 'vault-result',  id, ok, result?,   error? }
 *   helper → page : { source: 'aero-oops-wtf-helper', type: 'vault-fetch-event', id, event }
 *
 * `fetch` performs a request; `browse` drives a tab the extension itself
 * opened (see background.js's browse section); `vault` manages the page's
 * saved keys (vault.js). Each is one round trip with a page-supplied `id`,
 * and none can be cancelled once sent.
 *
 * `vault-fetch` is the one that streams: a request made with a saved key, its
 * answer arriving as a run of `vault-fetch-event`s (`head`, then `chunk`s,
 * then `end` or `error`; `closed` if the worker's side went away first). Each
 * has a port of its own to the worker, and `vault-cancel` disconnects it,
 * which aborts the request there.
 *
 * Waking up is not being served: the worker answers only pages at origins
 * the user trusts (background.js, "Who may ask"). `trusted` in the hello says
 * whether this page is one, so Aero can tell the user what to do instead of
 * failing on its first request.
 */

'use strict';

var VERSION = chrome.runtime.getManifest().version;
var activated = false;

function announce() {
  chrome.runtime.sendMessage({ type: 'aero-hello' }, function (resp) {
    var trusted = !chrome.runtime.lastError && !!(resp && resp.trusted);
    window.postMessage(
      { source: 'aero-oops-wtf-helper', type: 'hello', version: VERSION, trusted: trusted },
      window.location.origin
    );
  });
}

/** Detect Aero's meta marker and activate once. */
function tryActivate() {
  if (activated) return;
  var meta = document.querySelector('meta[name="aero-oops-wtf"][content="true"]');
  if (!meta) return;
  activated = true;
  announce();
}

// document_start runs before <head> exists; poll for the meta tag.
// A MutationObserver catches it whether it's in the static HTML or injected
// later by the SPA router.
var observer = new MutationObserver(tryActivate);
observer.observe(document.documentElement, { childList: true, subtree: true });
tryActivate();

/**
 * The request types this relay carries. The two differ only in which worker
 * message they name and what the reply field is called, so they share one
 * path through the listener below.
 *
 * Module scope: it never varies per call, and the listener runs on every
 * ping, fetch and browse.
 *
 * Null-prototype, and read through hasOwnProperty: a plain object literal
 * would answer `type === 'toString'` with an inherited function, which is
 * truthy and would then be read for `.message`/`.reply`. Only an activated
 * same-origin page can reach the listener, so this is a shape guard rather
 * than a live hole — but the page half of this bridge is the untrusted half.
 */
var KINDS = Object.create(null);
KINDS.fetch = { message: 'aero-fetch', reply: 'fetch-result', payload: 'response' };
KINDS.browse = { message: 'aero-browse', reply: 'browse-result', payload: 'result' };
KINDS.vault = { message: 'aero-vault', reply: 'vault-result', payload: 'result' };

/** Open `vault-fetch` requests, by the page's request id: `{ port, keepalive }`. */
var vaultPorts = Object.create(null);

/**
 * How often an open request pings the worker. Chrome stops an extension's
 * service worker after 30s with nothing to do, and a request waiting on a
 * slow first byte, or a stream gone quiet mid-answer, is nothing to do: on
 * 2026-11-08 two requests whose answers took 70s and 150s to start were cut
 * off at 30s. With this ping, and the worker answering it, both completed.
 */
var KEEPALIVE_MS = 20000;

function vaultEvent(id, event) {
  window.postMessage(
    { source: 'aero-oops-wtf-helper', type: 'vault-fetch-event', id: id, event: event },
    window.location.origin
  );
}

function startVaultFetch(id, req) {
  if (vaultPorts[id]) return;
  var port;
  try {
    port = chrome.runtime.connect({ name: 'vault-fetch' });
  } catch (e) {
    // The extension was reloaded under this page: its old content script
    // can no longer reach the worker at all.
    vaultEvent(id, {
      type: 'error',
      message: 'helper extension unavailable: ' + (e && e.message ? e.message : String(e)) +
        ' (reload this page)',
    });
    return;
  }
  var keepalive = setInterval(function () {
    try {
      port.postMessage({ type: 'keepalive' });
    } catch (e) {
      // Disconnected; the listener below has cleared this.
    }
  }, KEEPALIVE_MS);
  vaultPorts[id] = { port: port, keepalive: keepalive };
  port.onMessage.addListener(function (event) {
    // The worker's answer to the ping above; nothing for the page.
    if (event && event.type === 'keepalive') return;
    vaultEvent(id, event);
  });
  port.onDisconnect.addListener(function () {
    void chrome.runtime.lastError;
    clearInterval(keepalive);
    if (!vaultPorts[id]) return;
    delete vaultPorts[id];
    // After `end` or `error` the page has finished and ignores this.
    vaultEvent(id, { type: 'closed' });
  });
  port.postMessage({ type: 'request', req: req });
}

function cancelVaultFetch(id) {
  var open = vaultPorts[id];
  if (!open) return;
  delete vaultPorts[id];
  clearInterval(open.keepalive);
  open.port.disconnect();
}

function kindOf(type) {
  if (typeof type !== 'string') return null;
  if (!Object.prototype.hasOwnProperty.call(KINDS, type)) return null;
  return KINDS[type];
}

window.addEventListener('message', function (ev) {
  if (!activated) return;
  if (ev.source !== window || ev.origin !== window.location.origin) return;
  var d = ev.data;
  if (!d || d.source !== 'aero-oops-wtf-page') return;

  if (d.type === 'ping') {
    announce();
    return;
  }
  if (d.type === 'vault-fetch' && typeof d.id === 'string') {
    startVaultFetch(d.id, d.req);
    return;
  }
  if (d.type === 'vault-cancel' && typeof d.id === 'string') {
    cancelVaultFetch(d.id);
    return;
  }

  var kind = kindOf(d.type);
  if (kind && typeof d.id === 'string') {
    var id = d.id;
    chrome.runtime.sendMessage({ type: kind.message, req: d.req }, function (resp) {
      if (chrome.runtime.lastError) {
        window.postMessage(
          {
            source: 'aero-oops-wtf-helper',
            type: kind.reply,
            id: id,
            ok: false,
            error: 'helper extension unavailable: ' + chrome.runtime.lastError.message +
              ' (try reloading the extension on chrome://extensions)',
          },
          window.location.origin
        );
        return;
      }
      var out = {
        source: 'aero-oops-wtf-helper',
        type: kind.reply,
        id: id,
        ok: !!(resp && resp.ok),
        error: resp && resp.error,
      };
      out[kind.payload] = resp && resp[kind.payload];
      window.postMessage(out, window.location.origin);
    });
  }
});
